import os,zipfile,json
from pathlib import Path
os.environ['VL_AUDIT_APP']='work/app-virtual49.py'
script=Path('work/analyze_controls43.py').read_text(encoding='utf-8')
for directory,label in [('same-inputs-891-2.00.49','behavior-same'),('IP1000_external_no-recovery_2.00.49','behavior-fresh'),('resource-matrix-891-2.00.49','behavior-resources')]:
 os.environ['VL_AUDIT_DATA']='outputs/'+directory;os.environ['VL_AUDIT_OUT']='outputs/full-matrix-review-2.00.49/'+label
 head,tail=script.split('rows=json.loads',1);ns={};exec(head,ns)
 if label=='behavior-resources':
  def root(path,fmt):
   with zipfile.ZipFile(path) as z:
    name='description.xml' if fmt=='GDTF' else next(n for n in z.namelist() if '/' not in n and n.lower().endswith('.xml'))
    return ns['m']['parse'](z.read(name).decode('utf-8-sig'))
  ns['root']=root;tail=tail.replace("else '.xml';source=","else '.zip';source=")
 exec('rows=json.loads'+tail,ns)

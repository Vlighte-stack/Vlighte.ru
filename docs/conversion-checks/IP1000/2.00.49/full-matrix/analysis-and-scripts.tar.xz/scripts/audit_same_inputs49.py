"""Offline boundary-stripped conversion audit. No application patches or archive writes."""
import os,runpy,base64,tempfile,shutil,zipfile,io,json,hashlib,collections,itertools,csv,html
from pathlib import Path
from decimal import Decimal,InvalidOperation
from lxml import etree
os.environ['VLIGHTE_GEO_BOOTSTRAP']='0'
m=runpy.run_path('work/app-virtual49.py');g=m['import_profile'].__globals__
assert 'def native_scale' in Path('work/app-virtual49.py').read_text(encoding='utf-8')
OUT=Path('outputs/same-inputs-891-2.00.49');OUT.mkdir(exist_ok=True)
SCHEMA=etree.XMLSchema(etree.parse('work/gdtf-1.2.xsd'))
FORMATS=['MA','HOG','GDTF'];EXT={'MA':'.xml','HOG':'.xml','GDTF':'.gdtf'}
def dump(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def xmlclean(raw):
 root=m['parse'](raw.decode('utf-8-sig'))
 for parent in root.iter():
  for child in list(parent):
   if not isinstance(child.tag,str):parent.remove(child)
 raw=m['serialize'](root).encode();assert b'<!--' not in raw;return raw
def clean(raw,fmt):
 if fmt!='GDTF':return xmlclean(raw)
 out=io.BytesIO()
 with zipfile.ZipFile(io.BytesIO(raw)) as z,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as w:
  for item in z.infolist():w.writestr(item,xmlclean(z.read(item)) if item.filename=='description.xml' else z.read(item))
 return out.getvalue()
def rootof(raw,fmt):return m['parse']((zipfile.ZipFile(io.BytesIO(raw)).read('description.xml') if fmt=='GDTF' else raw).decode('utf-8-sig'))
def job(imp,source):
 c=m['first'](m['parse'](imp['xml']),'CompoundType');parts=m['children'](m['first'](c,'Parts'),'Part')
 return {'resourceBase64':imp.get('resourceBase64'),'xml':imp['xml'],'sourceXml':source,'compoundIndex':0,'name':c.get('name'),'exportGdtf':True,'parts':[{'type':p.get('type'),'number':p.get('number'),'plotX':p.get('plotX','0'),'plotY':p.get('plotY','0'),'sourceIndex':i} for i,p in enumerate(parts)]}
def transform(raw,src,dst,mode=None):
 raw=clean(raw,src)
 if src=='GDTF':
  encoded=base64.b64encode(raw).decode();choices=m['import_profile']({'gdtf':encoded});chosen=mode or choices['modes'][0]['name'];imp=m['import_profile']({'gdtf':encoded,'mode':chosen});source=imp['sourceXml']
 else:source=raw.decode();imp=m['import_profile']({'xml':source})
 result=m['generate_formats'](job(imp,source))
 if dst=='GDTF':
  if not result.get('gdtfBase64'):raise ValueError(result.get('gdtfError','No GDTF output'))
  output=base64.b64decode(result['gdtfBase64'])
 else:output=result['xml' if dst=='HOG' else 'ma2Xml'].encode()
 output=clean(output,dst);root=rootof(output,dst)
 if dst=='GDTF':
  descriptor=zipfile.ZipFile(io.BytesIO(output)).read('description.xml')
  if not SCHEMA.validate(etree.fromstring(descriptor)):raise ValueError('Generated GDTF XSD: '+str(SCHEMA.error_log.last_error))
 else:(m['validate_hog'] if dst=='HOG' else m['validate_ma2'])(root)
 return output,list(dict.fromkeys(imp.get('warnings',[])+result.get('warnings',[])))
def num(value):
 try:
  d=Decimal(value)
  if d.is_finite():return str(d.normalize()) if d else '0'
 except (InvalidOperation,ValueError):pass
 return value
def node(n,ignore=()):return [m['local'](n),{k:num(v) for k,v in sorted(n.attrib.items()) if k not in ignore},(n.text or '').strip(),[node(c,ignore) for c in n if isinstance(c.tag,str)]]
def flat(n):
 result={}
 def walk(n,path):
  for k,v in sorted(n.attrib.items()):result[path+'/@'+k]=v
  if (n.text or '').strip():result[path+'/#text']=n.text.strip()
  counts=collections.Counter()
  for c in n:
   if isinstance(c.tag,str):
    tag=m['local'](c);counts[tag]+=1;walk(c,path+'/'+tag+'['+str(counts[tag])+']')
 walk(n,'/'+m['local'](n));return result
def delta(a,b):return [{'path':p,'original':a.get(p),'result':b.get(p)} for p in sorted(set(a)|set(b)) if a.get(p)!=b.get(p)]
def ma_snapshot(root):
 modules={n.get('index'):n for n in m['descendants'](root,'Module')};instances=m['descendants'](root,'Instance');records={};occupied=set();counts=collections.Counter();cursor=1
 for inst in instances:
  module=modules[inst.get('module_index')];patch=int(inst.get('patch',str(cursor)));width=0
  for index,ch in enumerate(m['children'](module,'ChannelType')):
   physical='coarse' in ch.attrib;coarse=int(ch.get('coarse','0'));fine=int(ch.get('fine','0'));address=patch+coarse-1 if physical else None
   key='DMX '+str(address) if physical else 'Virtual '+str(patch)+' '+ch.get('attribute','')+' '+str(index)
   rec=node(ch,('index','coarse','fine'));records[key]={'bits':16 if fine else 8 if physical else 0,'definition':rec}
   if physical:
    occupied.add(address);width=max(width,coarse)
    if fine:occupied.add(patch+fine-1);width=max(width,fine)
   counts['channels']+=1;counts['virtual']+=not physical;counts['functions']+=len(m['children'](ch,'ChannelFunction'));counts['sets']+=len(m['descendants'](ch,'ChannelSet'));counts['defaults']+='default' in ch.attrib
  cursor=patch+width
 return {'footprint':m['validate_ma2'](root),'slots':len(occupied),'modules':len(modules),'instances':len(instances),**dict(counts)},records
def hog_snapshot(root):
 types={t.get('name'):t for t in m['descendants'](root,'Type')};cursor=1;records={};parts=m['children'](m['first'](root,'Parts'),'Part')
 for part in parts:
  t=types[part.get('type')]
  for ch in m['descendants'](t,'Channel'):
   records['DMX '+str(cursor+int(ch.get('number'))-1)]=node(ch,('number',))
  for vi,v in enumerate(m['descendants'](t,'Virtual')):records['Virtual '+str(cursor)+' '+str(vi)]=node(v)
  for di,d in enumerate(m['descendants'](t,'Default')):records['Default '+str(cursor)+' '+str(di)]=node(d)
  cursor+=int(m['first'](t,'Dmxfootprint').get('size'))
 return {'footprint':cursor-1,'modules':len(types),'instances':len(parts),'channels':len(records),'functions':sum(len(m['descendants'](t,'Range')) for t in types.values())},records
def snapshot(raw,fmt,mode=None):
 root=rootof(raw,fmt)
 if fmt=='MA':return ma_snapshot(root)
 if fmt=='HOG':return hog_snapshot(root)
 fixture=m['first'](root,'FixtureType');modes=m['descendants'](fixture,'DMXMode');chosen=next((x for x in modes if x.get('Name')==mode),modes[0]);ma,summary,_=m['gdtf_to_ma'](root,fixture,chosen);stats,records=ma_snapshot(ma);stats['mode']=chosen.get('Name');return stats,records
def compare(a,b,fmt,mode=None):
 original,originalrec=snapshot(a,fmt,mode);result,resultrec=snapshot(b,fmt,mode)
 changed=delta(originalrec,resultrec);xmlchanges=delta(flat(rootof(a,fmt)),flat(rootof(b,fmt)))
 return {'original':original,'result':result,'channelDifferences':changed,'channelDifferenceCount':len(changed),'xmlDifferences':xmlchanges,'xmlDifferenceCount':len(xmlchanges),'status':'MATCH' if not changed else 'DIFFERENT'}
def pack_descriptor(raw):
 out=io.BytesIO()
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:z.writestr('description.xml',raw)
 return out.getvalue()
external=Path('work/external-fixtures-20261026');sources=json.loads((external/'sources.json').read_text(encoding='utf-8'))
fixtures=[{'id':'IP1000','format':'MA','raw':Path('C:/Users/Admin/Documents/@strobe1000_light@42ch.xml').read_bytes(),'source':'User MA2 @strobe1000_light@42ch.xml'}]
for index,source in enumerate(sources):
 p=external/source['file'];raw=p.read_bytes();raw=pack_descriptor(raw) if p.suffix=='.xml' else raw;root=rootof(raw,'GDTF');fixture=m['first'](root,'FixtureType');modes=m['descendants'](fixture,'DMXMode')
 fixtures.append({'id':f'{index+1:02}_'+fixture.get('Name','Fixture').replace('/','_').replace('®','').replace('™','').strip(),'format':'GDTF','raw':raw,'mode':modes[0].get('Name'),'source':source,'fixture':fixture.attrib,'availableModes':[x.get('Name') for x in modes]})
dump(OUT/'sources.json',[{k:v for k,v in f.items() if k!='raw'} for f in fixtures])
rows=[];details=[];seedrows=[]
with tempfile.TemporaryDirectory() as tmp:
 private=Path(tmp)/'private';private.mkdir();(private/'known.json').write_text('{}');shutil.copyfile('C:/Users/Admin/Documents/HOG4_1000 42.xml',private/'strobe.xml');g['ROOT']=Path(tmp)
 for f in fixtures:
  folder=OUT/f['id'];folder.mkdir(exist_ok=True);seeds={};seederrors={};native=clean(f['raw'],f['format']);(folder/('original-'+f['format']+EXT[f['format']])).write_bytes(native)
  for fmt in FORMATS:
   try:
    raw=(Path('outputs/same-inputs-891-2.00.45')/f['id']/('seed-'+fmt+EXT[fmt])).read_bytes();stats,_=snapshot(raw,fmt,f.get('mode') if fmt==f['format'] else None);seeds[fmt]=raw;(folder/('seed-'+fmt+EXT[fmt])).write_bytes(raw);seedrows.append({'fixture':f['id'],'format':fmt,'status':'READY','stats':stats,'native':fmt==f['format']})
   except Exception as e:seederrors[fmt]=str(e);seedrows.append({'fixture':f['id'],'format':fmt,'status':'ERROR','error':str(e),'native':fmt==f['format']})
  cache={(fmt,):(raw,[]) for fmt,raw in seeds.items()}
  def prefix(path):
   if path in cache:
    value=cache[path]
    if isinstance(value,Exception):raise value
    return value
   try:
     previous,warnings=prefix(path[:-1]);value,notes=transform(previous,path[-2],path[-1],f.get('mode') if len(path)==2 and path[0]==f['format'] else None)
     disk=folder/'steps'/('-'.join(path)+EXT[path[-1]]);disk.parent.mkdir(exist_ok=True);disk.write_bytes(value);value=disk.read_bytes();cache[path]=(value,warnings+notes);return cache[path]
   except Exception as e:cache[path]=e;raise
  for start in FORMATS:
   for middle in itertools.product(FORMATS,repeat=3):
    path=(start,)+middle+(start,);name='-'.join(path);record={'fixture':f['id'],'chain':name,'start':start,'nativeStart':start==f['format'],'changesEveryStep':all(a!=b for a,b in zip(path,path[1:]))}
    try:
     if start not in seeds:raise ValueError('Initial '+start+' unavailable: '+seederrors[start])
     final,warnings=prefix(path);comparison=compare(seeds[start],final,start,f.get('mode') if start==f['format'] else None);record.update(comparison);record['warnings']=sorted(set(warnings));record['finalSha256']=hashlib.sha256(final).hexdigest();record['originalSha256']=hashlib.sha256(seeds[start]).hexdigest()
     (folder/(name+EXT[start])).write_bytes(final)
    except Exception as e:
     completed=0
     for length in range(2,6):
      if path[:length] in cache and not isinstance(cache[path[:length]],Exception):completed=length-1
      else:break
     record.update(status='ERROR',error=str(e),completedSteps=completed,failedStep=completed+1 if start in seeds else 0,failedTransition=path[completed]+'-'+path[completed+1] if start in seeds else 'seed-'+start)
    if f['id']=='IP1000' and path==('MA','HOG','GDTF','HOG','MA'):
     chainfolder=folder/'requested-chain';chainfolder.mkdir(exist_ok=True)
     for i in range(1,6):
      try:(chainfolder/(f'{i-1:02}_'+'-'.join(path[:i])+EXT[path[i-1]])).write_bytes(prefix(path[:i])[0])
      except Exception:break
     dump(chainfolder/'comparison.json',record)
    details.append(record);summary={k:record.get(k) for k in ('fixture','chain','start','nativeStart','changesEveryStep','status','channelDifferenceCount','xmlDifferenceCount','failedStep','failedTransition','error')};rows.append(summary)
  dump(folder/'matrix-details.json',[r for r in details if r['fixture']==f['id']]);print(json.dumps({'fixture':f['id'],'results':dict(collections.Counter(r['status'] for r in rows if r['fixture']==f['id']))}),flush=True)
dump(OUT/'seeds.json',seedrows);dump(OUT/'matrix.json',rows)
with (OUT/'matrix.csv').open('w',encoding='utf-8-sig',newline='') as stream:
 w=csv.DictWriter(stream,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
counts=collections.Counter(r['status'] for r in rows);requested=next(r for r in details if r['fixture']=='IP1000' and r['chain']=='MA-HOG-GDTF-HOG-MA')
lines=['# Проверки без комментариев восстановления — 2.00.49','','Код установленной версии 2.00.49; SHA256 фиксируется в сводном отчёте. Все XML-комментарии рекурсивно удалены из входов и выходов каждого преобразования; GDTF очищается внутри description.xml. Следующий этап получает только заново прочитанные определения предыдущего формата. known.json пустой: готовые известные профили не подставляются. Внутренняя обработка одной операции приложением сохранена.','','Матрица: 81 замкнутая цепочка из четырёх операций для каждого прибора (3 начальных формата × 3³ промежуточных варианта). Включены операции сохранения в тот же формат. Из них 18 цепочек меняют формат на каждом шаге. Для сторонних GDTF выбран первый объявленный DMX-режим; он указан в sources.json. Ошибки не заменяются подбором другого режима. Начальные MA/HOG, полученные из стороннего GDTF, являются производными: их успешный цикл не доказывает сохранность оригинального GDTF.','','MATCH означает совпадение развёрнутых определений каналов, DIFFE­RENT — обнаружены отличия, ERROR — цепочка или исходное преобразование отклонены. Нормализуются числовая запись и индексы; имена атрибутов, диапазоны, умолчания и ChannelSet сравниваются. Полные различия XML также записаны. Это сравнение определений, не проверка физического поведения приборов.','','## IP1000: MA → HOG → GDTF → HOG → MA','',f"Результат: **{requested['status']}**."]
if 'original' in requested:
 lines+=['','| Параметр | Оригинал | Результат |','|---|---:|---:|']
 for key in requested['original']:lines.append(f"| {key} | {requested['original'][key]} | {requested['result'].get(key)} |")
 lines+=['',f"Изменённых определений каналов: {requested['channelDifferenceCount']}. Отличий элементов/атрибутов XML: {requested['xmlDifferenceCount']}. Подробности и файлы всех этапов: IP1000/requested-chain/."]
else:lines+=['',requested.get('error','')]
lines+=['','## Общая матрица','','| Прибор | Совпало | Отличается | Ошибка |','|---|---:|---:|---:|']
for f in fixtures:
 c=collections.Counter(r['status'] for r in rows if r['fixture']==f['id']);lines.append(f"| {f['id']} | {c['MATCH']} | {c['DIFFERENT']} | {c['ERROR']} |")
lines+=['',f"Всего {len(rows)} цепочек: {dict(counts)}.",'','Полная матрица: matrix.csv, matrix.json и интерактивная matrix.html. seeds.json показывает доступность начальных форматов. В каждом каталоге matrix-details.json содержит ошибки и конкретные различия. Схема GDTF 1.2 проверяется на каждом сформированном GDTF, но не заменяет проверку импорта на пульте. Исходники приложения, сайт и файловая библиотека не изменялись.','','## Источники сторонних профилей','']
lines += ['- '+s['file']+': '+s['url']+' (Git blob '+s['blobSha']+')' for s in sources]
(OUT/'Отчёт.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
table=''.join('<tr class="'+r['status']+'"><td>'+html.escape(r['fixture'])+'</td><td>'+html.escape(r['chain'])+'</td><td>'+('оригинал' if r['nativeStart'] else 'производный')+'</td><td>'+r['status']+'</td><td>'+str(r.get('channelDifferenceCount') or '')+'</td><td>'+html.escape(r.get('error') or '')+'</td></tr>' for r in rows)
(OUT/'matrix.html').write_text('<!doctype html><meta charset="utf-8"><title>IP1000 — матрица без восстановления</title><style>body{font:16px system-ui;margin:24px;background:#f4f1ea}input{padding:12px;width:70%}table{border-collapse:collapse;background:white;margin-top:20px}td,th{padding:8px;border:1px solid #ddd;text-align:left}.ERROR{background:#fff0ef}.DIFFERENT{background:#fff8df}.MATCH{background:#edfaee}</style><h1>Матрица четырёх преобразований без комментариев</h1><p>11 приборов, 81 цепочка на каждый. Начальный и конечный форматы совпадают. Производные исходники отмечены отдельно.</p><input id="q" placeholder="Фильтр: IP1000, MA-HOG-GDTF-HOG-MA, ERROR…"><table><thead><tr><th>Прибор</th><th>Цепочка</th><th>Начало</th><th>Результат</th><th>Каналы с отличиями</th><th>Ошибка</th></tr></thead><tbody>'+table+'</tbody></table><script>q.oninput=()=>document.querySelectorAll("tbody tr").forEach(r=>r.hidden=!r.textContent.toLowerCase().includes(q.value.toLowerCase()))</script>',encoding='utf-8')
print(json.dumps({'total':len(rows),'counts':dict(counts),'requested':{k:v for k,v in requested.items() if k not in ('xmlDifferences','channelDifferences','warnings')}},ensure_ascii=True),flush=True)

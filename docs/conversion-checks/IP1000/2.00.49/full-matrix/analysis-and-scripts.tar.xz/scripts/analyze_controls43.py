"""Independent same-format behavioral probes; never use MA recovery for GDTF."""
import os,runpy,json,zipfile,math,collections,csv
from pathlib import Path
os.environ['VLIGHTE_GEO_BOOTSTRAP']='0';m=runpy.run_path(os.environ.get('VL_AUDIT_APP','work/app-breaks40.py'))
BASE=Path(os.environ.get('VL_AUDIT_DATA','outputs/IP1000_external_no-recovery_2.00.40'));OUT=Path(os.environ.get('VL_AUDIT_OUT','outputs/semantic-analysis-2.00.40'));OUT.mkdir(parents=True,exist_ok=True)
def root(path,fmt):return m['parse']((zipfile.ZipFile(path).read('description.xml') if fmt=='GDTF' else path.read_bytes()).decode('utf-8-sig'))
def family(name):
 aliases={'Dimmer':'DIM','Pan':'PAN','Tilt':'TILT','ColorAdd_R':'COLORRGB1','ColorAdd_G':'COLORRGB2','ColorAdd_B':'COLORRGB3','ColorAdd_W':'WHITE','Shutter1':'SHUTTER1','Shutter1Strobe':'SHUTTER1','NoFeature':'DUMMY','Intensity':'DIM','I Red':'COLORRGB1','I Green':'COLORRGB2','I Blue':'COLORRGB3','I White':'WHITE','BG White':'WHITE','Strobe':'SHUTTER1','CTO':'CTO','Zoom':'ZOOM','Pan 2':'PAN2','Tilt 2':'TILT2','Gobo':'GOBO1','Gobo 2':'GOBO2','Gobo <>':'GOBO1_POS','Gobo 2 <>':'GOBO2_POS','Colour Mode':'COLORMIXMODE','PanRotate':'PAN2','TiltRotate':'TILT2','Gobo1Pos':'GOBO1_POS','Gobo2Pos':'GOBO2_POS','Play Mode':'PLAYMODE','Fixture Control':'CONTROL1','Zone':'LEDZONEMODE','Pattern':'PATTERNSELECTION','Pattern <>':'PATTERNROTATION','Pattern Fade':'PATTERNFADE','Pattern Mode':'PATTERNTRANSITION','X':'XYZ_X','Y':'XYZ_Y','Z':'XYZ_Z','ColorAdd_RY':'AMBER','COLORADD_RY':'AMBER','ColorAdd_A':'AMBER','COLORRGB4':'AMBER','I Amber':'AMBER'}
 name=name[8:] if name.startswith('Vlighte_') else name
 name=aliases.get(name,name.upper())
 if name=='COLORRGB7':return 'WHITE'
 if name.startswith('DIMMER') and name[6:].isdigit():return 'DIM'+name[6:]
 return name
def number(x,default=0):
 try:return float(x) if x is not None else default
 except (ValueError,TypeError):return None
def ma_channels(r):
 mods={n.get('index'):n for n in m['descendants'](r,'Module')};physical={};virtual={};labels=[]
 for inst in m['descendants'](r,'Instance'):
  patch=int(inst.get('patch','1'));mod=mods[inst.get('module_index')];lookup={c.get('attribute'):c for c in m['children'](mod,'ChannelType')}
  for c in m['children'](mod,'ChannelType'):
   bits=16 if c.get('fine') else 8 if c.get('coarse') else 32;maximum=2**bits-1;key=(1,patch+int(c.get('coarse'))-1) if c.get('coarse') else ('virtual',patch,family(c.get('attribute','')));record={'bits':bits,'fine':patch+int(c.get('fine'))-1 if c.get('fine') else None,'attribute':family(c.get('attribute','')),'default':number(c.get('default'),'implicit-zero'),'ranges':[]}
   if record['default']=='implicit-zero':record['default']=0
   fns=m['children'](c,'ChannelFunction')
   if fns and all(f.get('attribute') in ('DUMMY','RESERVED') for f in fns):record['attribute']='DUMMY'
   master=lookup.get(c.get('mode'))
   for fn in m['children'](c,'ChannelFunction'):
    low=round(int(fn.get('min_dmx_24','0'))*maximum/16777215);high=round(int(fn.get('max_dmx_24','16777215'))*maximum/16777215);condition=(patch+int(master.get('coarse'))-1,int(fn.get('mode_dmx_start','0')),int(fn.get('mode_dmx_end','255'))) if master is not None else None;sets=[]
    for s in m['children'](fn,'ChannelSet'):
     a=int(s.get('from_dmx',str(low)));b=int(s.get('to_dmx',str(high)));sets.append({'lo':a,'hi':b,'label':s.get('name','')})
    record['ranges'].append({'lo':low,'hi':high,'pf':number(fn.get('physfrom')), 'pt':number(fn.get('physto'),1),'condition':condition,'attribute':family(fn.get('attribute',c.get('attribute',''))),'sets':sets})
   if not c.get('coarse'):
    record['affected']=sorted(patch+int(pc.get('coarse'))-1 for pc in m['children'](mod,'ChannelType') if pc.get('coarse') and any(f.get('attribute') not in ('DUMMY','RESERVED') for f in m['children'](pc,'ChannelFunction')) and (family(pc.get('attribute','')).startswith('COLORRGB') or family(pc.get('attribute','')) in ('WHITE','AMBER','RED','GREEN','BLUE')))
   (physical if c.get('coarse') else virtual)[key]=record
 return physical,virtual
def native_physical(fn):
 if fn.get('feature')=='Slots':
  function=fn.get('function')
  if function=='Colour Mode':return 0.,0.
  if function in ('Gobo','Gobo 2','Gobo 3'):return 1.,1.
  raise ValueError('Unmodelled physical interpretation of Slots: '+str(function))
 a=number(fn.get('start'));b=number(fn.get('end',fn.get('start')))
 if a is None or b is None:raise ValueError('Unmodelled HOG physical range')
 return a,b

def independent_condition(t,fn,cursor):
 groups=m['children'](fn,'Qualifiers')
 if not groups:return None
 assert len(groups)==1
 group=groups[0];alternatives=[];addresses=set()
 for qualifier in m['children'](group,'Qualifier'):
  intervals=[]
  for controller in m['descendants'](t,'Channel'):
   for segment in m['descendants'](controller,'Range'):
    if any(segment.get(k)!=qualifier.get(k) for k in ('function','feature')):continue
    lo=int(segment.get('dmxstart'));hi=int(segment.get('dmxend',str(lo)))
    if segment.get('feature')=='Slots':
     if qualifier.get('start')!=qualifier.get('end',qualifier.get('start')):raise ValueError('Slot interval not implemented by audit')
     if segment.get('start')!=qualifier.get('start'):continue
     left,right=lo,hi
    else:
     a,b=native_physical(segment);qa=number(qualifier.get('start'));qb=number(qualifier.get('end',qualifier.get('start')))
     if qa is None or qb is None:raise ValueError('Unknown qualifier')
     x,y=max(min(a,b),qa),min(max(a,b),qb)
     if x>y+1e-9:continue
     if a==b:left,right=lo,hi
     else:
      p=lo+(hi-lo)*(x-a)/(b-a);q=lo+(hi-lo)*(y-a)/(b-a);left=math.ceil(min(p,q)-1e-6);right=math.floor(max(p,q)+1e-6)
    if left<=right:intervals.append((left,right));addresses.add(cursor+int(controller.get('number'))-1)
  if not intervals:raise ValueError('Qualifier never true')
  alternatives.append(intervals)
 assert len(addresses)==1
 spans=alternatives[0]
 for other in alternatives[1:]:
  spans=spans+other if group.get('match')=='any' else [(max(a,c),min(b,d)) for a,b in spans for c,d in other if max(a,c)<=min(b,d)]
 spans.sort();assert spans
 a,b=spans[0]
 for c,d in spans[1:]:assert c<=b+1;b=max(b,d)
 return next(iter(addresses)),a,b

def hog_channels(r):
 ts={n.get('name'):n for n in m['descendants'](r,'Type')};physical={};virtual={};cursor=1
 for part in m['children'](m['first'](r,'Parts'),'Part'):
  t=ts[part.get('type')];controls={}
  for c in m['descendants'](t,'Channel'):
   for fn in m['descendants'](c,'Range'):controls[(fn.get('function'),fn.get('feature'))]=cursor+int(c.get('number'))-1
  for c in m['descendants'](t,'Channel'):
   address=cursor+int(c.get('number'))-1;attached=m['descendants'](c,'AttachedChannel');bits=16 if attached else 8;rs=m['descendants'](c,'Range');initial=rs[0].get('function') if rs else 'DUMMY';record={'bits':bits,'fine':cursor+int(attached[0].text)-1 if attached else None,'attribute':family(initial),'default':None,'ranges':[]};defaults=[]
   inverse={'I Red':'Cyan','I Green':'Magenta','I Blue':'Yellow'}.get(initial)
   if not rs or c.get('unused')=='true' or 'constant' in c.attrib:record['constant']=int(c.get('constant','0'));record['default']=record['constant'];record['attribute']='DUMMY'
   for fn in rs:
    if fn.get('function')==inverse:continue
    low=int(fn.get('dmxstart'));high=int(fn.get('dmxend',str(low)));a,b=native_physical(fn);condition=independent_condition(t,fn,cursor)
    record['ranges'].append({'lo':low,'hi':high,'pf':a,'pt':b,'condition':condition,'attribute':family(fn.get('function','')),'sets':[]})
    for default in m['descendants'](t,'Default'):
     if any(default.get(k)!=fn.get(k) for k in ('function','feature')):continue
     if fn.get('feature')=='Slots':
      if default.get('value')==fn.get('start'):defaults.append(low)
     else:
      value=number(default.get('value'))
      if value is not None and min(a,b)-1e-9<=value<=max(a,b)+1e-9:defaults.append(low+(high-low)*(value-a)/(b-a) if a!=b else low)
   if defaults:record['default']=defaults[0]
   physical[(1,address)]=record
  for v in m['descendants'](t,'Virtual'):
   virtual[('virtual',cursor,family(v.get('function'))) ]={'bits':32,'attribute':family(v.get('function')),'ranges':[{'lo':0,'hi':2**32-1,'pf':number(v.get('start')),'pt':number(v.get('end')),'condition':None,'attribute':family(v.get('function')),'sets':[]}],'affected':sorted(controls.get((a.get('function'),a.get('feature'))) for a in m['children'](v,'Affected'))}
  cursor+=int(m['first'](t,'Dmxfootprint').get('size'))
 return physical,virtual


def gdtf_channels(r):
 f=m['first'](r,'FixtureType');mode=m['descendants'](f,'DMXMode')[0];physical={};virtual={}
 for path,c,brk,offsets in m['expanded_gdtf_channels'](f,mode):
  lc=c.find('LogicalChannel');bits=len(offsets)*8 if offsets else 32;key=(brk,offsets[0]) if offsets else ('virtual',path,family(lc.get('Attribute')));record={'bits':bits,'fine':offsets[1] if len(offsets)>1 else None,'attribute':family(lc.get('Attribute')),'default':0,'ranges':[]};initial=c.get('InitialFunction','').split('.')[-1]
  if lc.findall('ChannelFunction') and all(fn.get('Attribute',lc.get('Attribute'))=='NoFeature' for fn in lc.findall('ChannelFunction')):record['attribute']='DUMMY'
  for fn,lo,hi,cond in m['gdtf_function_intervals'](lc,bits,mode):
   sets=fn.findall('ChannelSet');sstarts=[m['gdtf_dmx'](s.get('DMXFrom','0/1'),bits) for s in sets];sitems=[]
   for i,s in enumerate(sets):sitems.append({'lo':sstarts[i],'hi':sstarts[i+1]-1 if i+1<len(sets) else hi,'label':s.get('Name',''),'pfOverride':number(s.get('PhysicalFrom'),None),'ptOverride':number(s.get('PhysicalTo'),None),'wheelSlot':s.get('WheelSlotIndex') if int(s.get('WheelSlotIndex','0'))>0 else None})
   condition=None
   if cond[0]:
    controller=m['gdtf_master'](mode,cond[0]);controller_offsets=controller.get('Offset','').split(',');condition=(int(controller_offsets[0]),cond[1],cond[2])
   record['ranges'].append({'lo':lo,'hi':hi,'pf':number(fn.get('PhysicalFrom')),'pt':number(fn.get('PhysicalTo'),1),'condition':condition,'attribute':family(fn.get('Attribute',lc.get('Attribute'))),'sets':sitems})
   if fn.get('Name')==initial or len(record['ranges'])==1:record['default']=m['gdtf_dmx'](fn.get('Default','0/1'),bits)
  (physical if offsets else virtual)[key]=record
 return physical,virtual
def parse(path,fmt):
 r=root(path,fmt);return {'MA':ma_channels,'HOG':hog_channels,'GDTF':gdtf_channels}[fmt](r)
def value(record,dmx,condition):
 matches=[x for x in record['ranges'] if x['lo']<=dmx<=x['hi'] and x['condition']==condition]
 if len(matches)!=1:return None
 fn=matches[0];pf,pt=fn['pf'],fn['pt'];lo,hi=fn['lo'],fn['hi']
 if pf is None or pt is None:return None
 # Apply explicit ChannelSet physical overrides; absent overrides don't
 # manufacture additional physical ramps in this conservative probe.
 for s in fn['sets']:
  if s['lo']<=dmx<=s['hi'] and (s.get('pfOverride') is not None or s.get('ptOverride') is not None):pf=s.get('pfOverride') if s.get('pfOverride') is not None else pf;pt=s.get('ptOverride') if s.get('ptOverride') is not None else pt;lo,hi=s['lo'],s['hi'];break
 return pf+(pt-pf)*(dmx-lo)/(hi-lo) if hi!=lo else pf
def compare(a,b):
 old,ov=a;new,nv=b;issues=[]
 if set(old)!=set(new):issues.append({'category':'addressing','original':sorted(old),'result':sorted(new)})
 for key in sorted(set(old)&set(new)):
  x,y=old[key],new[key]
  if x['bits']!=y['bits'] or x['fine']!=y['fine']:issues.append({'dmx':key,'category':'resolution','original':[x['bits'],x['fine']],'result':[y['bits'],y['fine']]})
  if x.get('constant')!=y.get('constant') and ('constant' in x or 'constant' in y):issues.append({'dmx':key,'category':'constant_representation','original':x.get('constant'),'result':y.get('constant')})
  if x['attribute']!=y['attribute']:issues.append({'dmx':key,'category':'control_assignment','original':x['attribute'],'result':y['attribute']})
  if x.get('default') is not None and y.get('default') is not None:
   difference=abs(x['default']-y['default'])
   if difference>0.500001:issues.append({'dmx':key,'category':'default','original':x['default'],'result':y['default'],'delta':difference})
   elif difference>1e-7:issues.append({'dmx':key,'category':'quantization','original':x['default'],'result':y['default'],'delta':difference})
  xc={r['condition'] for r in x['ranges']};yc={r['condition'] for r in y['ranges']}
  if xc!=yc:issues.append({'dmx':key,'category':'conditions','original':sorted(map(str,xc)),'result':sorted(map(str,yc))})
  for condition in xc&yc:
   if x['ranges'] and all(r['attribute']=='DUMMY' for r in x['ranges']):continue
   points=set()
   for r in x['ranges']+y['ranges']:
    if r['condition']!=condition:continue
    points.update((r['lo'],r['hi'],(r['lo']+r['hi'])//2))
    for s in r['sets']:points.update((s['lo'],s['hi'],(s['lo']+s['hi'])//2))
   bad=[]
   for dmx in sorted(points):
    va,vb=value(x,dmx,condition),value(y,dmx,condition)
    if va is None or vb is None:
     if va!=vb:bad.append({'dmxValue':dmx,'original':va,'result':vb,'unresolved':True})
     continue
    if not math.isclose(va,vb,rel_tol=1e-8,abs_tol=1e-7):bad.append({'dmxValue':dmx,'original':va,'result':vb})
   if bad:issues.append({'dmx':key,'category':'physical_curve','condition':condition,'samples':bad[:8],'changedSamples':len(bad)})
  names=[s['label'] for r in x['ranges'] for s in r['sets'] if s['label']];newnames=[s['label'] for r in y['ranges'] for s in r['sets'] if s['label']]
  if names!=newnames:issues.append({'dmx':key,'category':'set_labels','originalCount':len(names),'resultCount':len(newnames)})
  slots=[s.get('wheelSlot') for r in x['ranges'] for s in r['sets'] if s.get('wheelSlot')];newslots=[s.get('wheelSlot') for r in y['ranges'] for s in r['sets'] if s.get('wheelSlot')]
  if slots!=newslots:issues.append({'dmx':key,'category':'wheel_visualization','originalCount':len(slots),'resultCount':len(newslots)})
 old_scope=sorted(tuple(v['affected']) for v in ov.values() if 'affected' in v);new_scope=sorted(tuple(v['affected']) for v in nv.values() if 'affected' in v)
 if old_scope!=new_scope:issues.append({'category':'virtual_scope','original':old_scope,'result':new_scope})
 if len(ov)!=len(nv):issues.append({'category':'virtual_count','original':len(ov),'result':len(nv)})
 return issues
rows=json.loads((BASE/'matrix.json').read_text(encoding='utf-8'));results=[];cache={}
for row in rows:
 if row['status']=='ERROR':continue
 folder=BASE/row['fixture'];fmt=row['start'];ext='.gdtf' if fmt=='GDTF' else '.xml';source=folder/('seed-'+fmt+ext);target=folder/(row['chain']+ext)
 def snapshot(path):
  if str(path) not in cache:cache[str(path)]=parse(path,fmt)
  return cache[str(path)]
 issues=compare(snapshot(source),snapshot(target));cats=sorted({i['category'] for i in issues});functional={'addressing','resolution','default','conditions','physical_curve','virtual_count','virtual_scope'};risk={'control_assignment','wheel_visualization'};classification='functional_difference' if functional&set(cats) else 'control_or_visualization_change' if risk&set(cats) else 'labels_structure_or_quantization'
 results.append({**row,'classification':classification,'categories':cats,'issues':issues})
(OUT/'analysis.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8');summary={'version':BASE.name,'rows':len(results),'previousDifferentRows':sum(r['status']=='DIFFERENT' for r in results),'classifications':dict(collections.Counter(r['classification'] for r in results)),'categoryRows':dict(collections.Counter(c for r in results for c in r['categories']))};(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(summary,ensure_ascii=True))

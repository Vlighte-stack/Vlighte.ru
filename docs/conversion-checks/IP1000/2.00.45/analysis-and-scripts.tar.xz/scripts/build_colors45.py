from pathlib import Path
s=Path('work/app-wheels44.py').read_text(encoding='utf-8')
needle="    if gdtf and not name.startswith('wheels/'):continue"
s=s.replace(needle,"    if name=='colorimetry.json' and not gdtf:\n     if info.file_size>512_000:raise ValueError('colorimetry.json превышает 512 КБ.')\n     data=z.read(info);color_manifest45(data);result[name]=data;continue\n"+needle,1)
assert "name=='colorimetry.json'" in s
helpers=Path('work/precise_colors45.py').read_text(encoding='utf-8');s=s.replace('def application(environ,start_response):',helpers+'\n\ndef application(environ,start_response):',1)
Path('work/app-colors45.py').write_text(s,encoding='utf-8')
for old,new in [('home-wheels44.html','home-colors45.html'),('library-wheels44.html','library-colors45.html')]:
 page=Path('work',old).read_text(encoding='utf-8').replace('2.00.44','2.00.45')
 if old.startswith('home'):
  page=page.replace("api('/api/import',{xml:saved.xml})","api('/api/import',{xml:saved.xml,resourceBase64:saved.resourceBase64})").replace("el('resourcePackage').checked=!!sourceResources;","el('resourcePackage').checked=!!sourceResources||data.preciseColors===true;")
  page=page.replace('loadXml(data.xml,file.name);sourceXml=xml;sourceName=file.name;','loadXml(data.xml,file.name);sourceXml=xml;sourceName=file.name;el(\'resourcePackage\').checked=data.preciseColors===true;')
  page=page.replace('ZIP с XML и ресурсами (для HOG4/MA2)</label>','ZIP с XML и ресурсами (для HOG4/MA2)</label><p class="save-hint">Для точного переноса цвета CIE через MA2 используйте ZIP с colorimetry.json. Для импорта XML в MA2 распакуйте архив.</p>')
 Path('work',new).write_text(page,encoding='utf-8')
for old,new in [('audit_wheels44.py','audit_colors45.py'),('audit_same_inputs44.py','audit_same_inputs45.py'),('audit_resources44.py','audit_resources45.py')]:
 s=Path('work',old).read_text(encoding='utf-8').replace('app-wheels44.py','app-colors45.py').replace('2.00.44','2.00.45')
 if 'same_inputs' in new:s=s.replace('outputs/same-inputs-891-2.00.43','outputs/same-inputs-891-2.00.44')
 Path('work',new).write_text(s,encoding='utf-8')
print('Built candidate 2.00.45')

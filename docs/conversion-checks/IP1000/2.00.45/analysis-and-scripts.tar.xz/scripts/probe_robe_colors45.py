exec(open('work/test_exact_colors45.py',encoding='utf-8').read().split('with tempfile.TemporaryDirectory() as td:')[0])
proof=[]
def bound_colors(raw):
 with zipfile.ZipFile(io.BytesIO(raw)) as z:r=m['parse'](z.read('description.xml').decode())
 f=m['first'](r,'FixtureType');mode=m['descendants'](f,'DMXMode')[0];wheels={w.get('Name'):w for w in f.findall('./Wheels/Wheel')};records=[]
 for _,c,brk,offsets in m['expanded_gdtf_channels'](f,mode):
  if not offsets:continue
  bits=len(offsets)*8
  for fn,_,hi,cond in m['gdtf_function_intervals'](c.find('LogicalChannel'),bits,mode):
   wheel=wheels.get(fn.get('Wheel'));slots=wheel.findall('Slot') if wheel is not None else [];sets=fn.findall('ChannelSet')
   for i,s in enumerate(sets):
    si=int(s.get('WheelSlotIndex','0'))-1
    if not 0<=si<len(slots):continue
    lo=m['gdtf_dmx'](s.get('DMXFrom','0/1'),bits);end=m['gdtf_dmx'](sets[i+1].get('DMXFrom','0/1'),bits)-1 if i+1<len(sets) else hi
    records.append((offsets[0],lo,end,slots[si].get('Name'),tuple(map(float,slots[si].get('Color','0.3127,0.329,100').split(',')))))
 return records
with tempfile.TemporaryDirectory() as td:
 g['ROOT']=Path(td);(Path(td)/'private').mkdir();(Path(td)/'private/known.json').write_text('{}');shutil.copyfile('C:/Users/Admin/Documents/HOG4_1000 42.xml',Path(td)/'private/strobe.xml')
 for fixture in ('09_Robin iSpiiderX','10_pixelPATT'):
  source=(Path('outputs/resource-matrix-891-2.00.44')/fixture/'original-GDTF.gdtf').read_bytes();original=bound_colors(source)
  for chain in (['GDTF','HOG','MA','HOG','GDTF'],['GDTF','HOG','GDTF','HOG','GDTF']):
   raw=source
   for src,dst in zip(chain,chain[1:]):
    raw=transform(raw,src,dst)
    if dst=='HOG' and 'MA' not in chain:
     with zipfile.ZipFile(io.BytesIO(raw)) as z:raw=z.read(next(n for n in z.namelist() if n.endswith('.xml')))
   final=bound_colors(raw);delta=0
   for address,lo,hi,name,values in original:
    for point in {lo,hi,(lo+hi)//2}:
     candidates=[v for a,l,h,n,v in final if a==address and l<=point<=h and n==name];assert len(candidates)==1,(fixture,address,point,name,candidates)
     delta=max(delta,max(abs(a-b) for a,b in zip(values,candidates[0])))
   assert delta<1e-10,(fixture,chain,delta);proof.append({'fixture':fixture,'chain':'-'.join(chain),'sourceBindings':len(original),'maxCieComponentDelta':delta,'hogStepsUseOnlyNativeXml': 'MA' not in chain})
out=Path('outputs/wheel-review-2.00.45');out.mkdir(exist_ok=True);(out/'robe-precision-verification.json').write_text(json.dumps(proof,indent=2),encoding='utf-8');print(proof)

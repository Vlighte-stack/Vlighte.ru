import os,runpy,tempfile,shutil
from pathlib import Path
from wsgiref.simple_server import make_server
os.environ['VLIGHTE_GEO_BOOTSTRAP']='0';m=runpy.run_path('work/app-colors45.py');g=m['application'].__globals__
td=tempfile.TemporaryDirectory();root=Path(td.name);(root/'private').mkdir();(root/'library').mkdir();(root/'private'/'known.json').write_text('{}');shutil.copyfile('C:/Users/Admin/Documents/HOG4_1000 42.xml',root/'private'/'strobe.xml');g['ROOT']=root;g['STORE']=root/'saved-files';g['owner_credentials']=lambda:None
def app(env,start):
 path=env.get('PATH_INFO','/')
 if path in ('/','/library/'):
  data=Path('work/'+('home-colors45.html' if path=='/' else 'library-colors45.html')).read_text(encoding='utf-8').replace('src="/logo-pencil.webp','src="https://vlighte.ru/logo-pencil.webp').encode();start('200 OK',[('Content-Type','text/html;charset=utf-8'),('Content-Length',str(len(data)))]);return [data]
 return m['application'](env,start)
print('Local isolated 2.00.45 on 127.0.0.1:8767',flush=True)
try:make_server('127.0.0.1',8767,app).serve_forever()
finally:td.cleanup()

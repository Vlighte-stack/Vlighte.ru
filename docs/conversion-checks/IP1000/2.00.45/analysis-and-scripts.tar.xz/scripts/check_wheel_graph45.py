"""Independent native palette audit. No converter round-trip snapshots are used."""
import os,json,zipfile,hashlib,collections,math
from pathlib import Path
os.environ['VLIGHTE_GEO_BOOTSTRAP']='0';os.environ['VL_AUDIT_APP']='work/app-colors45.py'
ns={};exec(Path('work/analyze_controls43.py').read_text(encoding='utf-8').split('rows=json.loads')[0],ns)
m=ns['m'];ch=m['children'];ds=m['descendants'];first=m['first']
OUT=Path('outputs/wheel-review-2.00.45');OUT.mkdir(exist_ok=True)
def load(path,fmt):
 if zipfile.is_zipfile(path):
  with zipfile.ZipFile(path) as z:
   name='description.xml' if fmt=='GDTF' else next(n for n in z.namelist() if '/' not in n and n.lower().endswith('.xml'))
   return m['parse'](z.read(name).decode('utf-8-sig')),{n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('wheels/') and n.lower().endswith(('.png','.jpg','.jpeg','.bmp'))}
 return m['parse'](path.read_text(encoding='utf-8-sig')),{}
def cie_rgb(v):
 x,y,Y=map(float,v.split(','));Y/=100
 if y<=0:return (0,0,0)
 return xyz_rgb((x*Y/y,Y,(1-x-y)*Y/y))
def xyz_rgb(v):
 X,Y,Z=v;linear=(3.2406*X-1.5372*Y-.4986*Z,-.9689*X+1.8758*Y+.0415*Z,.0557*X-.2040*Y+1.057*Z)
 def gamma(v):
  v=max(0,min(1,v));return round(255*(12.92*v if v<=.0031308 else 1.055*v**(1/2.4)-.055))
 return tuple(map(gamma,linear))
def graph(r,fmt):
 result=[];unbound=[]
 def add(addr,lo,hi,label,rgb,media,condition=None,cie=None,xyz=None):result.append(dict(address=addr,lo=lo,hi=hi,label=label,rgb=rgb,media=(media or '').replace('\\','/'),condition=condition,cie=cie,xyz=xyz))
 if fmt=='GDTF':
  f=first(r,'FixtureType');mode=ds(f,'DMXMode')[0];wheels={w.get('Name'):w for w in f.findall('./Wheels/Wheel')}
  for _,dc,brk,offsets in m['expanded_gdtf_channels'](f,mode):
   if not offsets:continue
   for fn,lo,hi,cond in m['gdtf_function_intervals'](dc.find('LogicalChannel'),len(offsets)*8,mode):
    wheel=wheels.get(fn.get('Wheel'));slots=wheel.findall('Slot') if wheel is not None else [];sets=fn.findall('ChannelSet')
    for i,s in enumerate(sets):
     si=int(s.get('WheelSlotIndex','0'))
     if si<=0:continue
     if si>len(slots):unbound.append((brk,offsets[0],si));continue
     slot=slots[si-1];a=m['gdtf_dmx'](s.get('DMXFrom','0/1'),len(offsets)*8);b=m['gdtf_dmx'](sets[i+1].get('DMXFrom','0/1'),len(offsets)*8)-1 if i+1<len(sets) else hi
     media=slot.get('MediaFileName');media='wheels/'+media+'.png' if media else None;cie=slot.get('Color','0.3127,0.329,100')
     add((brk,offsets[0]),a,b,slot.get('Name',''),cie_rgb(cie),media,str(cond),cie)
 elif fmt=='MA':
  wheels=ch(first(r,'Wheels'),'Wheel') if first(r,'Wheels') is not None else [];mods={n.get('index'):n for n in ds(r,'Module')}
  for inst in ds(r,'Instance'):
   for c in ch(mods[inst.get('module_index')],'ChannelType'):
    if not c.get('coarse'):continue
    addr=int(inst.get('patch','1'))+int(c.get('coarse'))-1
    for fn in ch(c,'ChannelFunction'):
     wi=int(fn.get('wheel','0'))-1
     for s in ch(fn,'ChannelSet'):
      if 'slot_index' not in s.attrib:continue
      si=int(s.get('slot_index'));slots=ch(wheels[wi],'Slot') if 0<=wi<len(wheels) else []
      if not 0<=si<len(slots):unbound.append((1,addr,si));continue
      slot=slots[si];add((1,addr),int(s.get('from_dmx','0')),int(s.get('to_dmx','255')),slot.get('media_name',''),tuple(int(slot.get(k,'255')) for k in ('r','g','b')),slot.get('media_filename'),str((c.get('mode'),fn.get('mode_dmx_start'),fn.get('mode_dmx_end'))))
 else:
  types={t.get('name'):t for t in ds(r,'Type')};cursor=1
  for part in ch(first(r,'Parts'),'Part'):
   t=types[part.get('type')]
   for preview in ds(t,'Funcpreview'):
    refs=ds(first(preview,'Definition'),'Funcref')
    if len(refs)!=1:continue
    identity=(refs[0].get('function'),refs[0].get('feature'));colors=[e for ref in ds(t,'funcref') if (ref.get('function'),ref.get('feature'))==identity for e in ch(ref,'entry')]
    for e in ch(preview,'Entry'):
     matches=[]
     for c in ds(t,'Channel'):
      for fn in ds(c,'Range'):
       if (fn.get('function'),fn.get('feature'))!=identity:continue
       if identity[1]=='Slots':match=e.get('value')==fn.get('start')
       else:
        try:a,b=ns['native_physical'](fn);match=min(a,b)-1e-9<=float(e.get('value'))<=max(a,b)+1e-9
        except (ValueError,TypeError):match=False
       if match:matches.append((c,fn))
     if len(matches)!=1:unbound.append(('preview',identity,e.get('value')));continue
     c,fn=matches[0];color=next((x for x in colors if x.get('value')==e.get('value')),None);rgb=xyz_rgb(tuple(float(color.get(k,'0')) for k in ('x','y','z'))) if color is not None else (255,255,255)
     add((1,cursor+int(c.get('number'))-1),int(fn.get('dmxstart')),int(fn.get('dmxend',fn.get('dmxstart'))),e.get('name',''),rgb,e.get('thumbnail'),str(ns['independent_condition'](t,fn,cursor)),xyz=tuple(float(color.get(k,'0')) for k in ('x','y','z')) if color is not None else None)
   cursor+=int(first(t,'Dmxfootprint').get('size'))
 return result,unbound
def compare_graph(a,b):
 issues=[]
 for x in a:
  ys=[y for y in b if y['address']==x['address'] and y['condition']==x['condition'] and y['lo']<=x['hi'] and y['hi']>=x['lo']]
  for point in {x['lo'],x['hi'],(x['lo']+x['hi'])//2,*[max(x['lo'],y['lo']) for y in ys],*[min(x['hi'],y['hi']) for y in ys]}:
   choices=[y for y in ys if y['lo']<=point<=y['hi']]
   if len(choices)!=1:issues.append(dict(category='wheel_binding',source=x,point=point,candidates=len(choices)));continue
   y=choices[0]
   for k in ('label','media'):
    if x[k]!=y[k]:issues.append(dict(category='wheel_'+k,address=x['address'],point=point,original=x[k],result=y[k]))
   if max(abs(p-q) for p,q in zip(x['rgb'],y['rgb']))>1:issues.append(dict(category='wheel_rgb',address=x['address'],point=point,original=x['rgb'],result=y['rgb']))
   if x['cie'] and y['cie'] and max(abs(float(p)-float(q)) for p,q in zip(x['cie'].split(','),y['cie'].split(',')))>1e-5:issues.append(dict(category='cie_to_rgb_representation',address=x['address'],point=point,original=x['cie'],result=y['cie']))
 return issues

PRECISION_STATS45={}
def attach_precision45(records,path,fmt,root):
 if fmt=='GDTF':
  for r in records:
   x,y,Y=map(float,r['cie'].split(','));r['xyz']=(x*Y/(100*y),Y/100,(1-x-y)*Y/(100*y)) if y else (0.,0.,0.)
 if fmt!='MA' or not zipfile.is_zipfile(path):return
 with zipfile.ZipFile(path) as z:
  if 'colorimetry.json' not in z.namelist():return
  doc=json.loads(z.read('colorimetry.json'));fingerprint=m['object_fingerprint'](m['serialize'](root));profiles=[p for p in doc['profiles'] if p['fingerprint']==fingerprint];assert len(profiles)==1
  for record in records:
   candidates=[b for b in profiles[0]['bindings'] if b['channel']==record['address'][1] and b['dmxFrom']==record['lo'] and b['dmxTo']==record['hi'] and b['name']==record['label'] and tuple(b['rgb'])==record['rgb']]
   if len(candidates)==1:record['xyz']=tuple(candidates[0]['xyz'])

def compare_precision45(a,b):
 issues=[]
 for x in a:
  if x.get('xyz') is None:continue
  for point in {x['lo'],x['hi'],(x['lo']+x['hi'])//2}:
   ys=[y for y in b if y['address']==x['address'] and y['condition']==x['condition'] and y['lo']<=point<=y['hi'] and y['label']==x['label']]
   if len(ys)!=1 or ys[0].get('xyz') is None:issues.append(dict(category='missing_exact_xyz',address=x['address'],point=point));continue
   delta=max(abs(p-q) for p,q in zip(x['xyz'],ys[0]['xyz']))
   PRECISION_STATS45['probes']+=1;PRECISION_STATS45['maxXYZDelta']=max(PRECISION_STATS45['maxXYZDelta'],delta)
   def xyY(xyz):
    X,Y,Z=xyz;total=X+Y+Z;return (X/total,Y/total,100*Y) if total else (0.,0.,0.)
   source_cie=tuple(map(float,x['cie'].split(','))) if x.get('cie') else xyY(x['xyz'])
   result_cie=tuple(map(float,ys[0]['cie'].split(','))) if ys[0].get('cie') else xyY(ys[0]['xyz'])
   cie_delta=max(abs(p-q) for p,q in zip(source_cie,result_cie))
   PRECISION_STATS45['maxCieComponentDelta']=max(PRECISION_STATS45['maxCieComponentDelta'],cie_delta)
   if delta>1e-12:issues.append(dict(category='xyz_precision_change',address=x['address'],point=point,delta=delta,original=x['xyz'],result=ys[0]['xyz']))
 return issues

def run(base,out):
 PRECISION_STATS45.update(probes=0,maxXYZDelta=0.,maxCieComponentDelta=0.)
 rows=json.loads((base/'matrix.json').read_text(encoding='utf-8'));results=[];cache={}
 def snap(p,fmt):
  key=str(p)
  if key not in cache:
   r,images=load(p,fmt);native=graph(r,fmt);attach_precision45(native[0],p,fmt,r);cache[key]=(native,images,r)
  return cache[key]
 for row in rows:
  fmt=row['start'];ext='.gdtf' if fmt=='GDTF' else '.zip' if 'resource-matrix' in str(base) else '.xml';folder=base/row['fixture'];a,ai,ar=snap(folder/('seed-'+fmt+ext),fmt);b,bi,br=snap(folder/(row['chain']+ext),fmt);issues=compare_graph(a[0],b[0]);issues+=compare_precision45(a[0],b[0]);imageissues=[n for n,v in ai.items() if bi.get(n)!=v]
  results.append(dict(fixture=row['fixture'],chain=row['chain'],start=fmt,sourceBindings=len(a[0]),resultBindings=len(b[0]),sourceUnbound=a[1],resultUnbound=b[1],issues=issues,imageChanges=imageissues,sourceImages=len(ai),resultImages=len(bi)))
 out.mkdir(exist_ok=True,parents=True);(out/'wheel-graphs.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8');summary=dict(precisionMetrics=dict(PRECISION_STATS45),rows=len(results),categoryRows=dict(collections.Counter(k for r in results for k in {i['category'] for i in r['issues']})),imageChangedRows=sum(bool(r['imageChanges']) for r in results),sourceUnboundRows=sum(bool(r['sourceUnbound']) for r in results),resultUnboundRows=sum(bool(r['resultUnbound']) for r in results));(out/'wheel-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(base,summary)
for dirname in ['same-inputs-891-2.00.45','IP1000_external_no-recovery_2.00.45','resource-matrix-891-2.00.45']:run(Path('outputs')/dirname,OUT/dirname)

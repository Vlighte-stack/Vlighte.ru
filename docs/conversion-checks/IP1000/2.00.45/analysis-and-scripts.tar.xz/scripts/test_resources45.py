import os,runpy,tempfile,shutil,base64,io,zipfile,json,hashlib,types,sys
from pathlib import Path
from lxml import etree
os.environ['VLIGHTE_GEO_BOOTSTRAP']='0';m=runpy.run_path('work/app-colors45.py');g=m['import_profile'].__globals__
def clean(xml):
 root=m['parse'](xml)
 for p in root.iter():
  for c in list(p):
   if not isinstance(c.tag,str):p.remove(c)
 return m['serialize'](root)
def clean_package(encoded):
 out=io.BytesIO()
 with zipfile.ZipFile(io.BytesIO(base64.b64decode(encoded))) as z,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as w:
  for n in z.namelist():w.writestr(n,clean(z.read(n).decode()) if n.lower().endswith('.xml') else z.read(n))
 return base64.b64encode(out.getvalue()).decode()
def job(imp):
 root=m['parse'](imp['xml']);c=m['first'](root,'CompoundType');parts=m['children'](m['first'](c,'Parts'),'Part')
 return {'xml':imp['xml'],'sourceXml':imp['sourceXml'],'compoundIndex':0,'name':c.get('name'),'exportGdtf':True,'exportBoth':True,'resourceBase64':imp.get('resourceBase64'),'packageFormat':'hog','parts':[{'type':p.get('type'),'number':p.get('number'),'plotX':p.get('plotX','0'),'plotY':p.get('plotY','0'),'sourceIndex':i} for i,p in enumerate(parts)]}
with tempfile.TemporaryDirectory() as td:
 g['ROOT']=Path(td);private=Path(td)/'private';private.mkdir();(private/'known.json').write_text('{}');shutil.copyfile('C:/Users/Admin/Documents/HOG4_1000 42.xml',private/'strobe.xml')
 source=Path('work/external-fixtures-20261026/BlenderDMX@BeskydBeam@version10.gdtf').read_bytes();encoded=base64.b64encode(source).decode();choices=m['import_profile']({'gdtf':encoded});imp=m['import_profile']({'gdtf':encoded,'mode':choices['modes'][0]['name']});assert imp['resourceCount']>0
 source_resources=m['read_resources44'](imp['resourceBase64'])[1];assert m['descendants'](m['parse'](imp['sourceXml']),'Wheel')
 result=m['generate_formats'](job(imp));assert result.get('gdtfBase64'),result.get('gdtfError');assert result.get('packageBase64')
 first_result=result
 out=Path('outputs/wheel-review-2.00.45');out.mkdir(parents=True,exist_ok=True);(out/'sample-HOG-resources.zip').write_bytes(base64.b64decode(result['packageBase64']))
 # Four boundaries, stripped XML comments each time; only the actual ZIP
 # profile and PNG files move forward. No database or old source is reused.
 for _ in range(3):
  imp=m['import_profile']({'package':clean_package(result['packageBase64'])});result=m['generate_formats'](job(imp))
 final=zipfile.ZipFile(io.BytesIO(base64.b64decode(result['gdtfBase64'])));root=m['E'].fromstring(final.read('description.xml'))
 for name,data in source_resources.items():assert final.read(name)==data
 refs=[s.get('MediaFileName') for s in root.findall('.//Wheel/Slot') if s.get('MediaFileName')];assert refs
 for ref in refs:assert 'wheels/'+ref+'.png' in final.namelist()
 schema=etree.XMLSchema(etree.parse('work/gdtf-1.2.xsd'));assert schema.validate(etree.fromstring(final.read('description.xml'))),str(schema.error_log)
 for profile in [first_result['xml'],result['xml']]:
  h=etree.fromstring(profile.encode());ns={'h':m['H']};lib=h.find('h:Library',ns);comp=lib.find('h:CompoundTypes',ns)
  if comp is not None:lib.remove(comp);h.find('.//h:Product',ns).append(comp)
  hs=etree.XMLSchema(etree.parse('work/hog-fixture.xsd'));assert hs.validate(h),str(hs.error_log)
 # Reject traversal, scripts, duplicate profiles, false image headers.
 rejected=0
 for files in [[('../evil.png',b'bad')],[('profile.xml',b'<x/>'),('evil.php',b'bad')],[('a.xml',b'<x/>'),('b.xml',b'<x/>')],[('profile.xml',b'<x/>'),('wheels/bad.png',b'\x89PNG\r\n\x1a\n')]]:
  zbuf=io.BytesIO()
  with zipfile.ZipFile(zbuf,'w') as z:
   for name,data in files:z.writestr(name,data)
  try:m['read_resources44'](base64.b64encode(zbuf.getvalue()).decode(),profile=True);raise AssertionError('Unsafe package accepted')
  except ValueError:rejected+=1
 sys.modules['fcntl']=types.SimpleNamespace(flock=lambda *a:None,LOCK_EX=2)
 g['STORE']=Path(td)/'saved-files';(Path(td)/'library').mkdir()
 g['owner_credentials']=lambda:{'username':'test-owner','hash':'ab'*32}
 origin={'ip':'192.0.2.1','countryCode':None,'generatedAt':'2026-10-27T00:00:00+00:00'}
 payload={'xml':first_result['xml'],'ma2Xml':first_result['ma2Xml'],'sourceXml':imp['sourceXml'],'sourceName':'test.xml','name':'Resource test','resourceBase64':first_result['resourceBase64'],'_requestOrigin':origin}
 receipt=m['origin_receipt'](origin,payload['xml'],payload['ma2Xml'],None,payload['resourceBase64']);payload['originReceipt']=receipt
 assert m['archive_origin'](payload,{})==origin
 try:m['archive_origin']({**payload,'resourceBase64':payload['resourceBase64']+'A'},{});raise AssertionError('Tampered resources accepted')
 except ValueError:pass
 record=m['save_pair'](payload,payload['xml']);folder=g['STORE']/record['id'];assert (folder/'.resources.zip').is_file()
 assert m['save_pair'](payload,payload['xml'])['duplicate']
 changed={**source_resources};changed['wheels/additional.png']=next(iter(source_resources.values()));assert not m['resource_identity_matches44'](record,{'resourceBase64':m['pack_resources44'](changed)})
 saved=m['read_saved_xml']('/api/files/'+record['id']+'/hog');stored_resources=m['read_resources44'](saved['resourceBase64'])[1];assert {n:d for n,d in stored_resources.items() if n!='colorimetry.json'}==source_resources;assert 'colorimetry.json' in stored_resources
 saved_ma=m['read_saved_xml']('/api/files/'+record['id']+'/ma2');reopened=m['import_profile']({'xml':saved_ma['xml'],'resourceBase64':saved_ma['resourceBase64']});assert reopened['preciseColors']
 expected={b['name']:b['xyz'] for b in m['hog_color_bindings45'](m['parse'](first_result['xml']))};actual={b['name']:b['xyz'] for b in m['hog_color_bindings45'](m['parse'](reopened['xml']))};assert expected==actual
 m['complete_gdtf_record'](record,{**payload,'gdtfBase64':first_result['gdtfBase64']})
 with zipfile.ZipFile(folder/'bundle.zip') as z:
  for name,data in source_resources.items():assert z.read(record['folder']+'/'+name)==data
 assert 'origin' not in m['public_record'](record) and 'ip' not in m['public_record'](record) and '192.0.2.1' not in json.dumps(m['public_record'](record))
 old_attach=g['attach_resources44'];g['attach_resources44']=lambda *a:(_ for _ in ()).throw(OSError('simulated write failure'))
 count=len(list(g['STORE'].glob('*/info.json')))
 try:m['save_pair_unlocked']({**payload,'name':'Failure test'},payload['xml']);raise AssertionError('Expected write failure')
 except OSError:pass
 finally:g['attach_resources44']=old_attach
 assert len(list(g['STORE'].glob('*/info.json')))==count
 proof={'sourceResourceFiles':len(source_resources),'imageSha256PreservedAcrossPackages':{n:hashlib.sha256(v).hexdigest() for n,v in source_resources.items()},'finalGdtfImageLinksValid':len(refs),'gdtfXsd':True,'hogNativeDefinitionsXsd':True,'unsafePackagesRejected':rejected,'recoveryCommentsStrippedAtBoundaries':True,'consoleImportTested':False,'resourceReceiptTamperRejected':True,'resourceBundleUpgradePreserved':True,'sameResourceDuplicateDetected':True,'changedResourcesAreDifferentObject':True,'resourceWriteFailureRolledBack':True}
 out=Path('outputs/wheel-review-2.00.45');out.mkdir(parents=True,exist_ok=True);(out/'resource-verification.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(proof))

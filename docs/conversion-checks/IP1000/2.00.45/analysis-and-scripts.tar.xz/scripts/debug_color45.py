exec(open('work/test_exact_colors45.py',encoding='utf-8').read().split('with tempfile.TemporaryDirectory() as td:')[0])
with tempfile.TemporaryDirectory() as td:
 g['ROOT']=Path(td);(Path(td)/'private').mkdir();(Path(td)/'private/known.json').write_text('{}');shutil.copyfile('C:/Users/Admin/Documents/HOG4_1000 42.xml',Path(td)/'private/strobe.xml')
 raw=Path('outputs/resource-matrix-891-2.00.44/09_Robin iSpiiderX/original-GDTF.gdtf').read_bytes();needle='Filter 247 (Filter Minus Green)'
 enc=base64.b64encode(raw).decode();label=m['import_profile']({'gdtf':enc})['modes'][0]['name'];source=m['gdtf_color_bindings45'](enc,label);print('source',[b for b in source if b['name']==needle]);print('mode',label)
 for src,dst in zip(['GDTF','HOG','MA','HOG'],['HOG','MA','HOG','GDTF']):
  raw=transform(raw,src,dst)
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   if dst=='MA':print(dst,[b for p in json.loads(z.read('colorimetry.json'))['profiles'] for b in p['bindings'] if b['name']==needle])
   elif dst=='HOG':
    root=m['parse'](z.read(next(n for n in z.namelist() if n.endswith('.xml'))).decode());print(dst,[{k:v for k,v in b.items() if not k.startswith('_')} for b in m['hog_color_bindings45'](root) if b['name']==needle])
   else:print(dst,colors(raw).get(needle))

import subprocess,sys,json
from pathlib import Path
paths=sorted(Path('work').glob('controls43_*test*.py'))
paths += [Path('work/test_controls43.py'),Path('work/test_native_controls43.py')]
results=[]
for p in paths:
 s=p.read_text(encoding='utf-8').replace('app-controls43.py','app-colors45.py').replace('2.00.43','2.00.45')
 q=p.with_name('colors45_'+p.name);q.write_text(s,encoding='utf-8')
 run=subprocess.run([sys.executable,str(q)],capture_output=True,text=True,encoding='utf-8')
 results.append(dict(script=str(q),exit=run.returncode,stdout=run.stdout,stderr=run.stderr));print(q.name,run.returncode,flush=True)
out=Path('outputs/wheel-review-2.00.45');out.mkdir(exist_ok=True);(out/'regressions.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
assert all(r['exit']==0 for r in results),[(r['script'],r['stderr'][-1200:]) for r in results if r['exit']]

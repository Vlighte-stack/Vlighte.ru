"""Native XYZ transfer plus explicit, profile-bound MA2 ZIP color data."""
import math
COLOR_MANIFEST45='colorimetry.json'

def xyz45(value):
 try:x,y,Y=map(real_number,value.split(','))
 except (AttributeError,ValueError):raise ValueError('Некорректный цвет CIE xyY.')
 if x<0 or y<0 or x+y>1.000001 or not 0<=Y<=100:raise ValueError('Цвет CIE выходит за допустимые границы.')
 if y==0:
  if Y!=0:raise ValueError('Ненулевая яркость CIE при y=0.')
  return (0.,0.,0.)
 values=(x*Y/(100*y),Y/100,(1-x-y)*Y/(100*y))
 if any(not 0<=v<100 for v in values):raise ValueError('Цвет XYZ не представим в нативном HOG.')
 return values

def cie45(values):
 X,Y,Z=map(real_number,values);total=X+Y+Z
 if not total:return '0,0,0'
 return ','.join(format(v,'.17g') for v in (X/total,Y/total,100*Y))

def color_manifest45(raw):
 if len(raw)>512_000:raise ValueError('colorimetry.json превышает 512 КБ.')
 try:doc=json.loads(raw)
 except (UnicodeError,ValueError):raise ValueError('Повреждён colorimetry.json.')
 if not isinstance(doc,dict) or set(doc)!={'schema','profiles'} or doc['schema']!='vlighte.colorimetry/1' or not isinstance(doc['profiles'],list) or len(doc['profiles'])>2:raise ValueError('Неизвестная структура colorimetry.json.')
 seen=set()
 for p in doc['profiles']:
  if not isinstance(p,dict) or set(p)!={'format','fingerprint','bindings'} or p['format']!='MA2' or not isinstance(p['fingerprint'],str) or not re.fullmatch('[0-9a-f]{64}',p['fingerprint']) or p['fingerprint'] in seen:raise ValueError('Некорректная привязка цветовых данных.')
  seen.add(p['fingerprint'])
  if not isinstance(p['bindings'],list) or len(p['bindings'])>4096:raise ValueError('Слишком много цветовых привязок.')
  for b in p['bindings']:
   if not isinstance(b,dict) or set(b)!={'channel','dmxFrom','dmxTo','wheel','slot','name','rgb','xyz'}:raise ValueError('Некорректная запись цвета.')
   for k in ('channel','dmxFrom','dmxTo','wheel','slot'):
    if type(b[k]) is not int:raise ValueError('Цветовая привязка требует целых индексов.')
   if not 1<=b['channel']<=65535 or not 0<=b['dmxFrom']<=b['dmxTo']<=65535 or not 1<=b['wheel']<=4096 or not 0<=b['slot']<4096 or not isinstance(b['name'],str) or len(b['name'])>4096:raise ValueError('Цветовая привязка вне допустимых границ.')
   if not isinstance(b['rgb'],list) or len(b['rgb'])!=3 or any(type(v) is not int or not 0<=v<=255 for v in b['rgb']):raise ValueError('Некорректный RGB цвета.')
   if not isinstance(b['xyz'],list) or len(b['xyz'])!=3 or any(type(v) not in (int,float) or not math.isfinite(v) or not 0<=v<100 for v in b['xyz']) or b['xyz'][1]>1:raise ValueError('Некорректный XYZ цвета.')
 return doc

def ma_color_bindings45(ma):
 holder=first(ma,'Wheels');wheels=children(holder,'Wheel') if holder is not None else [];result=[]
 for address,c in ma_physical_channels44(ma).items():
  for fn in children(c,'ChannelFunction'):
   wi=int(fn.get('wheel','0'))-1
   if not 0<=wi<len(wheels):continue
   slots=children(wheels[wi],'Slot')
   for s in children(fn,'ChannelSet'):
    si=int(s.get('slot_index','-1'))
    if not 0<=si<len(slots):continue
    slot=slots[si];result.append({'channel':address,'dmxFrom':int(s.get('from_dmx','0')),'dmxTo':int(s.get('to_dmx','255')),'wheel':wi+1,'slot':si,'name':slot.get('media_name',''),'rgb':[int(slot.get(k,'255')) for k in ('r','g','b')]})
 return result

def hog_color_bindings45(hog):
 types={t.get('name'):t for t in descendants(hog,'Type')};compound=first(hog,'CompoundType');result=[];cursor=1
 for part in children(first(compound,'Parts'),'Part'):
  t=types[part.get('type')]
  for preview in descendants(t,'Funcpreview'):
   refs=descendants(first(preview,'Definition'),'Funcref')
   if len(refs)!=1:continue
   identity=(refs[0].get('function'),refs[0].get('feature'))
   refs_colors=[e for ref in descendants(t,'funcref') if (ref.get('function'),ref.get('feature'))==identity for e in children(ref,'entry')]
   for entry in children(preview,'Entry'):
    colors=[n for n in refs_colors if n.get('value')==entry.get('value') and all(k in n.attrib for k in ('x','y','z'))]
    if len(colors)!=1:continue
    matches=[(c,r) for c in descendants(t,'Channel') for r in descendants(c,'Range') if (r.get('function'),r.get('feature'))==identity and value_matches44(r,entry.get('value'))]
    if len(matches)!=1:continue
    c,r=matches[0];result.append({'channel':cursor+int(c.get('number'))-1,'dmxFrom':int(r.get('dmxstart')),'dmxTo':int(r.get('dmxend',r.get('dmxstart'))),'name':entry.get('name',''),'xyz':[real_number(colors[0].get(k)) for k in ('x','y','z')],'_type':t,'_range':r,'_entry':entry})
  cursor+=int(first(t,'Dmxfootprint').get('size'))
 return result

def apply_hog_colors45(hog,bindings):
 # Existing native previews define the actual slot. We never encode a
 # source document or invent a color channel to transport metadata.
 types={t.get('name'):t for t in descendants(hog,'Type')};cursor=1;written={};layout=module_metadata(hog)
 for part_index,part in enumerate(children(first(first(hog,'CompoundType'),'Parts'),'Part')):
  t=types[part.get('type')]
  for preview in descendants(t,'Funcpreview'):
   refs=descendants(first(preview,'Definition'),'Funcref')
   if len(refs)!=1:continue
   identity=(refs[0].get('function'),refs[0].get('feature'))
   for entry in children(preview,'Entry'):
    matches=[(c,r) for c in descendants(t,'Channel') for r in descendants(c,'Range') if (r.get('function'),r.get('feature'))==identity and value_matches44(r,entry.get('value'))]
    if len(matches)!=1:continue
    c,r=matches[0];address=cursor+int(c.get('number'))-1;lo=int(r.get('dmxstart'));hi=int(r.get('dmxend',str(lo)))
    # During an import, compact editable modules can have interleaved DMX
    # patches. Resolve their existing layout before applying native colors.
    # Once generated, HOG parts are contiguous and need no import metadata.
    if layout:
     placement=layout['placements'][part_index];definition=layout['modules'][part.get('type')];spec=next(n for n in definition['channels'] if n['number']==int(c.get('number')));address=placement['patch']+spec['offset']-1
    colors=[b for b in bindings if b['channel']==address and b['dmxFrom']<=lo<=hi<=b['dmxTo'] and b['name']==entry.get('name','')]
    values={tuple(b['xyz']) for b in colors}
    if not values:continue
    if len(values)!=1:raise ValueError('Неоднозначная привязка CIE к HOG-превью.')
    xyz=next(iter(values));key=(id(t),identity,entry.get('value'))
    if key in written and written[key]!=xyz:raise ValueError('Общий модуль содержит разные цвета CIE; требуется отдельный модуль.')
    written[key]=xyz;cm=first(t,'ColourMatcher')
    if cm is None:cm=hog_type_section(t,'ColourMatcher');cm.set('type','slotted');cm.set('quality','chromaticity')
    refs_cm=[n for n in children(cm,'funcref') if (n.get('function'),n.get('feature'))==identity]
    ref=refs_cm[0] if refs_cm else E.SubElement(cm,q('funcref'),function=identity[0],feature=identity[1])
    entries=[n for n in children(ref,'entry') if n.get('value')==entry.get('value')]
    color=entries[0] if entries else E.SubElement(ref,q('entry'),value=entry.get('value'))
    for k,v in zip(('x','y','z'),xyz):color.set(k,format(v,'.17g'))
 return hog

def gdtf_color_bindings45(encoded,label):
 root,fixture,modes=read_gdtf(encoded);chosen=None
 for mode in modes:
  active=sorted({b for _,_,b,offsets in expanded_gdtf_channels(fixture,mode) if offsets})
  for brk in active:
   name=mode.get('Name') if len(active)==1 else mode.get('Name')+' [DMX Break '+str(brk)+']'
   if name==label:chosen=(mode,brk)
 if chosen is None:raise ValueError('Не найден режим для цветовых данных GDTF.')
 mode,selected=chosen;wheels={w.get('Name'):w for w in fixture.findall('./Wheels/Wheel')};result=[]
 for _,dc,brk,offsets in expanded_gdtf_channels(fixture,mode):
  if not offsets or brk!=selected:continue
  bits=len(offsets)*8
  for fn,lo,hi,_ in gdtf_function_intervals(dc.find('LogicalChannel'),bits,mode):
   wheel=wheels.get(fn.get('Wheel'));slots=wheel.findall('Slot') if wheel is not None else [];sets=fn.findall('ChannelSet')
   for i,s in enumerate(sets):
    si=int(s.get('WheelSlotIndex','0'))-1
    if not 0<=si<len(slots):continue
    a=gdtf_dmx(s.get('DMXFrom','0/1'),bits);b=gdtf_dmx(sets[i+1].get('DMXFrom','0/1'),bits)-1 if i+1<len(sets) else hi;slot=slots[si]
    result.append({'channel':offsets[0],'dmxFrom':a,'dmxTo':b,'name':slot.get('Name',''),'xyz':xyz45(slot.get('Color','0.3127,0.329,100'))})
 return result

def apply_gdtf_colors45(encoded,bindings):
 raw=base64.b64decode(encoded);root,fixture,modes=read_gdtf(encoded);wheels={w.get('Name'):w for w in fixture.findall('./Wheels/Wheel')};written={}
 for _,dc,_,offsets in expanded_gdtf_channels(fixture,modes[0]):
  if not offsets:continue
  bits=len(offsets)*8
  for fn,lo,hi,_ in gdtf_function_intervals(dc.find('LogicalChannel'),bits,modes[0]):
   wheel=wheels.get(fn.get('Wheel'));slots=wheel.findall('Slot') if wheel is not None else [];sets=fn.findall('ChannelSet')
   for i,s in enumerate(sets):
    si=int(s.get('WheelSlotIndex','0'))-1
    if not 0<=si<len(slots):continue
    slot=slots[si];a=gdtf_dmx(s.get('DMXFrom','0/1'),bits);b=gdtf_dmx(sets[i+1].get('DMXFrom','0/1'),bits)-1 if i+1<len(sets) else hi
    values={tuple(n['xyz']) for n in bindings if n['channel']==offsets[0] and n['dmxFrom']<=a<=b<=n['dmxTo'] and n['name']==slot.get('Name','')}
    if not values:continue
    if len(values)!=1:raise ValueError('Неоднозначная привязка CIE к слоту GDTF.')
    value=cie45(next(iter(values)))
    if id(slot) in written and written[id(slot)]!=value:raise ValueError('Один слот объединяет разные исходные цвета CIE.')
    written[id(slot)]=value;slot.set('Color',value)
 # Keep the existing ordinary generation receipt valid. This comment is
 # neither read nor needed by the color path, and audits strip it.
 for c in root:
  if c.tag is E.Comment and (c.text or '').startswith(GDTF_EXPORT_MARKER):
   data=json.loads(base64.b64decode(c.text[len(GDTF_EXPORT_MARKER):]));data['hash']=object_fingerprint(serialize(root));c.text=GDTF_EXPORT_MARKER+base64.b64encode(json.dumps(data,separators=(',',':')).encode()).decode()
 out=io.BytesIO()
 with zipfile.ZipFile(io.BytesIO(raw)) as old,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
  for info in old.infolist():
   if info.filename!=COLOR_MANIFEST45:z.writestr(info,serialize(root).encode() if info.filename=='description.xml' else old.read(info))
 return base64.b64encode(out.getvalue()).decode()

_import_profile44=import_profile

def import_profile(payload):
 result=_import_profile44(payload)
 if 'xml' not in result:return result
 bindings=[]
 if payload.get('gdtf') and payload.get('mode') is not None:bindings=gdtf_color_bindings45(payload['gdtf'],payload['mode'])
 elif payload.get('package') or payload.get('resourceBase64'):
  if payload.get('package'):xml,resources=read_resources44(payload['package'],profile=True)
  else:xml=payload['xml'];_,resources=read_resources44(payload['resourceBase64'])
  source=parse(xml)
  if source.tag==mq('MA') and COLOR_MANIFEST45 in resources:
   doc=color_manifest45(resources[COLOR_MANIFEST45]);p=next((p for p in doc['profiles'] if p['fingerprint']==object_fingerprint(xml)),None)
   if p is None:raise ValueError('colorimetry.json не соответствует MA2 XML. Загрузите согласованный ZIP или обычный XML без точных цветовых данных.')
   native=ma_color_bindings45(source)
   for b in p['bindings']:
    guard={k:v for k,v in b.items() if k!='xyz'}
    if guard not in native:raise ValueError('Привязка CIE не соответствует слоту MA2.')
   bindings=p['bindings']
 if bindings:result['xml']=serialize(apply_hog_colors45(strip_recovery(parse(result['xml'])),bindings))
 result['preciseColors']=bool(hog_color_bindings45(parse(result['xml'])))
 return result

_generate_formats44=generate_formats

def generate_formats(payload):
 result=_generate_formats44(payload);hog=parse(result['xml']);bindings=hog_color_bindings45(hog)
 if not bindings:return result
 if result.get('gdtfBase64'):result['gdtfBase64']=apply_gdtf_colors45(result['gdtfBase64'],bindings)
 resources=read_resources44(payload['resourceBase64'])[1] if payload.get('resourceBase64') else {};resources.pop(COLOR_MANIFEST45,None);profiles={}
 for xml in [result['ma2Xml'],payload.get('sourceXml')]:
  if not xml or parse(xml).tag!=mq('MA'):continue
  native=ma_color_bindings45(parse(xml));records=[]
  for b in native:
   values={tuple(n['xyz']) for n in bindings if n['channel']==b['channel'] and n['dmxFrom']<=b['dmxFrom']<=b['dmxTo']<=n['dmxTo'] and n['name']==b['name']}
   if len(values)==1:records.append({**b,'xyz':list(next(iter(values)))})
  if records:
   fingerprint=object_fingerprint(xml);profiles[fingerprint]={'format':'MA2','fingerprint':fingerprint,'bindings':records}
 if profiles:
  data=json.dumps({'schema':'vlighte.colorimetry/1','profiles':list(profiles.values())},ensure_ascii=False,separators=(',',':')).encode();color_manifest45(data);resources[COLOR_MANIFEST45]=data
  result['warnings']=list(dict.fromkeys(result.get('warnings',[])+['Точные XYZ сохранены в GDTF/HOG и colorimetry.json пакета. В самой MA2 и отдельном MA2 XML используется приближённый RGB.']))
  result['resourceBase64']=pack_resources44(resources);result['resourceCount']=sum(n!=COLOR_MANIFEST45 for n in resources)
 if payload.get('packageFormat') in ('hog','ma2'):result['packageBase64']=pack_resources44(resources,result['xml' if payload['packageFormat']=='hog' else 'ma2Xml'],export_filename(payload.get('sourceXml') or payload['xml'],payload['packageFormat'],payload['name']))
 return result

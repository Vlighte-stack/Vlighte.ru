import os,runpy,base64,io,zipfile,json,tempfile,shutil,math,copy
from pathlib import Path
os.environ['VLIGHTE_GEO_BOOTSTRAP']='0';m=runpy.run_path('work/app-colors45.py');g=m['application'].__globals__
def clean(raw):
 r=m['parse'](raw.decode('utf-8-sig'))
 for p in r.iter():
  for c in list(p):
   if not isinstance(c.tag,str):p.remove(c)
 return m['serialize'](r).encode()
def strip(raw,fmt):
 if fmt=='HOG' and not zipfile.is_zipfile(io.BytesIO(raw)):return clean(raw)
 out=io.BytesIO()
 with zipfile.ZipFile(io.BytesIO(raw)) as z,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as w:
  for n in z.namelist():w.writestr(n,clean(z.read(n)) if n.endswith('.xml') else z.read(n))
 return out.getvalue()
def transform(raw,src,dst):
 raw=strip(raw,src)
 if src=='GDTF':
  enc=base64.b64encode(raw).decode();choice=m['import_profile']({'gdtf':enc});imp=m['import_profile']({'gdtf':enc,'mode':choice['modes'][0]['name']})
 elif src=='MA' or zipfile.is_zipfile(io.BytesIO(raw)):imp=m['import_profile']({'package':base64.b64encode(raw).decode()})
 else:imp=m['import_profile']({'xml':raw.decode()});imp['sourceXml']=raw.decode()
 root=m['parse'](imp['xml']);compound=m['first'](root,'CompoundType');parts=m['children'](m['first'](compound,'Parts'),'Part')
 job={'xml':imp['xml'],'sourceXml':imp['sourceXml'],'resourceBase64':imp.get('resourceBase64'),'compoundIndex':0,'name':compound.get('name'),'exportGdtf':True,'packageFormat':'ma2' if dst=='MA' else 'hog' if dst=='HOG' else None,'parts':[{'type':p.get('type'),'number':p.get('number'),'plotX':p.get('plotX','0'),'plotY':p.get('plotY','0'),'sourceIndex':i} for i,p in enumerate(parts)]}
 result=m['generate_formats'](job)
 return base64.b64decode(result['gdtfBase64'] if dst=='GDTF' else result['packageBase64'])
def colors(raw):
 with zipfile.ZipFile(io.BytesIO(raw)) as z:r=m['parse'](z.read('description.xml').decode())
 return {s.get('Name'):tuple(map(float,s.get('Color','0.3127,0.329,100').split(','))) for s in r.findall('.//Wheels/Wheel/Slot')}
with tempfile.TemporaryDirectory() as td:
 g['ROOT']=Path(td);(Path(td)/'private').mkdir();(Path(td)/'private/known.json').write_text('{}');shutil.copyfile('C:/Users/Admin/Documents/HOG4_1000 42.xml',Path(td)/'private/strobe.xml')
 source=Path('work/external-fixtures-20261026/BlenderDMX@BeskydBeam@version10.gdtf').read_bytes();original=colors(source)
 raw=source;chain=['GDTF','HOG','MA','HOG','GDTF'];steps=[]
 for src,dst in zip(chain,chain[1:]):raw=transform(raw,src,dst);steps.append(raw)
 final=colors(raw);assert set(original)<=set(final),(set(original)-set(final),set(final)-set(original));delta=max(abs(a-b) for name,old in original.items() for a,b in zip(old,final[name]));assert delta<1e-10,delta
 ma=steps[1]
 with zipfile.ZipFile(io.BytesIO(ma)) as z:
  doc=json.loads(z.read('colorimetry.json'));xmlname=next(n for n in z.namelist() if n.endswith('.xml'));xml=z.read(xmlname);assert b'<!--' in xml or xml
  assert len(doc['profiles'])<=2 and doc['profiles'][0]['bindings'];assert all(set(b)=={'channel','dmxFrom','dmxTo','wheel','slot','name','rgb','xyz'} for p in doc['profiles'] for b in p['bindings'])
  manifest=copy.deepcopy(doc);manifest['profiles'][0]['fingerprint']='0'*64
  buf=io.BytesIO()
  with zipfile.ZipFile(buf,'w') as bad:
   for n in z.namelist():bad.writestr(n,json.dumps(manifest).encode() if n=='colorimetry.json' else z.read(n))
 try:m['import_profile']({'package':base64.b64encode(buf.getvalue()).decode()});raise AssertionError('Stale manifest accepted')
 except ValueError as e:assert 'не соответствует' in str(e)
 bad=copy.deepcopy(doc);bad['profiles'][0]['bindings'][0]['xyz'][0]=float('nan')
 try:m['color_manifest45'](json.dumps(bad).encode());raise AssertionError('NaN accepted')
 except ValueError:pass
 out=Path('outputs/wheel-review-2.00.45');out.mkdir(exist_ok=True);(out/'example-MA-with-colorimetry.zip').write_bytes(strip(ma,'MA'));(out/'example-colorimetry.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf-8');proof={'chain':'-'.join(chain),'maxCieComponentDelta':delta,'inputWheelSlotCount':len(original),'finalWheelSlotCount':len(final),'commentsStrippedAtEveryBoundary':True,'maPackageCarriesOpenXyzBindings':True,'maNativeRgbApproximationUnchanged':True,'mismatchedProfileRejected':True,'nonfiniteColorRejected':True,'consoleImportTested':False};(out/'exact-color-verification.json').write_text(json.dumps(proof,indent=2),encoding='utf-8');print(proof)

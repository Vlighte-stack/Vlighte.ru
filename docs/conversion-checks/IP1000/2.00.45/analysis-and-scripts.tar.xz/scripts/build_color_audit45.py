from pathlib import Path
s=Path('work/check_wheel_graph44.py').read_text(encoding='utf-8').replace('app-wheels44.py','app-colors45.py').replace('2.00.44','2.00.45')
s=s.replace('cie=None):result.append','cie=None,xyz=None):result.append').replace('cie=cie))','cie=cie,xyz=xyz))')
old="add((1,cursor+int(c.get('number'))-1),int(fn.get('dmxstart')),int(fn.get('dmxend',fn.get('dmxstart'))),e.get('name',''),rgb,e.get('thumbnail'),str(ns['independent_condition'](t,fn,cursor)))"
new=old[:-1]+",xyz=tuple(float(color.get(k,'0')) for k in ('x','y','z')) if color is not None else None)"
assert old in s;s=s.replace(old,new)
s=s.replace("issues=compare_graph(a[0],b[0]);imageissues=", "issues=compare_graph(a[0],b[0]);issues+=compare_precision45(a[0],b[0]);imageissues=")
s=s.replace("r,images=load(p,fmt);cache[key]=(graph(r,fmt),images,r)","r,images=load(p,fmt);native=graph(r,fmt);attach_precision45(native[0],p,fmt,r);cache[key]=(native,images,r)")
helper='''
PRECISION_STATS45={}
def attach_precision45(records,path,fmt,root):
 if fmt=='GDTF':
  for r in records:
   x,y,Y=map(float,r['cie'].split(','));r['xyz']=(x*Y/(100*y),Y/100,(1-x-y)*Y/(100*y)) if y else (0.,0.,0.)
 if fmt!='MA' or not zipfile.is_zipfile(path):return
 with zipfile.ZipFile(path) as z:
  if 'colorimetry.json' not in z.namelist():return
  doc=json.loads(z.read('colorimetry.json'));fingerprint=m['object_fingerprint'](m['serialize'](root));profiles=[p for p in doc['profiles'] if p['fingerprint']==fingerprint];assert len(profiles)==1
  for record in records:
   candidates=[b for b in profiles[0]['bindings'] if b['channel']==record['address'][1] and b['dmxFrom']==record['lo'] and b['dmxTo']==record['hi'] and b['name']==record['label'] and tuple(b['rgb'])==record['rgb']]
   if len(candidates)==1:record['xyz']=tuple(candidates[0]['xyz'])

def compare_precision45(a,b):
 issues=[]
 for x in a:
  if x.get('xyz') is None:continue
  for point in {x['lo'],x['hi'],(x['lo']+x['hi'])//2}:
   ys=[y for y in b if y['address']==x['address'] and y['condition']==x['condition'] and y['lo']<=point<=y['hi'] and y['label']==x['label']]
   if len(ys)!=1 or ys[0].get('xyz') is None:issues.append(dict(category='missing_exact_xyz',address=x['address'],point=point));continue
   delta=max(abs(p-q) for p,q in zip(x['xyz'],ys[0]['xyz']))
   PRECISION_STATS45['probes']+=1;PRECISION_STATS45['maxXYZDelta']=max(PRECISION_STATS45['maxXYZDelta'],delta)
   def xyY(xyz):
    X,Y,Z=xyz;total=X+Y+Z;return (X/total,Y/total,100*Y) if total else (0.,0.,0.)
   source_cie=tuple(map(float,x['cie'].split(','))) if x.get('cie') else xyY(x['xyz'])
   result_cie=tuple(map(float,ys[0]['cie'].split(','))) if ys[0].get('cie') else xyY(ys[0]['xyz'])
   cie_delta=max(abs(p-q) for p,q in zip(source_cie,result_cie))
   PRECISION_STATS45['maxCieComponentDelta']=max(PRECISION_STATS45['maxCieComponentDelta'],cie_delta)
   if delta>1e-12:issues.append(dict(category='xyz_precision_change',address=x['address'],point=point,delta=delta,original=x['xyz'],result=ys[0]['xyz']))
 return issues
'''
s=s.replace('def run(base,out):',helper+'\ndef run(base,out):',1)
s=s.replace('def run(base,out):\n','def run(base,out):\n PRECISION_STATS45.update(probes=0,maxXYZDelta=0.,maxCieComponentDelta=0.)\n',1)
s=s.replace("summary=dict(rows=len(results),", "summary=dict(precisionMetrics=dict(PRECISION_STATS45),rows=len(results),",1)
Path('work/check_wheel_graph45.py').write_text(s,encoding='utf-8')
print('Independent color audit prepared')

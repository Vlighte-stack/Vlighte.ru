import os,zipfile
from pathlib import Path
os.environ.update(VL_AUDIT_APP='work/app-colors45.py',VL_AUDIT_DATA='outputs/resource-matrix-891-2.00.45',VL_AUDIT_OUT='outputs/wheel-review-2.00.45/behavior-resources')
script=Path('work/analyze_controls43.py').read_text(encoding='utf-8');head,tail=script.split('rows=json.loads',1);ns={};exec(head,ns)
def root(path,fmt):
 with zipfile.ZipFile(path) as z:
  name='description.xml' if fmt=='GDTF' else next(n for n in z.namelist() if '/' not in n and n.lower().endswith('.xml'))
  return ns['m']['parse'](z.read(name).decode('utf-8-sig'))
ns['root']=root;exec('rows=json.loads'+tail.replace("else '.xml';source=","else '.zip';source="),ns)

from pathlib import Path
import hashlib,zipfile,json
out=Path('outputs/wheel-review-2.00.45');out.mkdir(exist_ok=True)
seeds=[]
for p in Path('outputs/same-inputs-891-2.00.44').glob('*/seed-*'):
 q=Path(str(p).replace('2.00.44','2.00.45'));a=hashlib.sha256(p.read_bytes()).hexdigest();b=hashlib.sha256(q.read_bytes()).hexdigest();assert a==b;seeds.append({'file':str(q),'sha256':a})
assert len(seeds)==33
counts={}
for dirname in ('same-inputs-891-2.00.45','IP1000_external_no-recovery_2.00.45','resource-matrix-891-2.00.45'):
 count=0
 for p in (Path('outputs')/dirname).rglob('*'):
  if p.suffix not in ('.xml','.zip','.gdtf') or not p.is_file():continue
  if zipfile.is_zipfile(p):
   with zipfile.ZipFile(p) as z:
    profiles=[n for n in z.namelist() if n=='description.xml' or '/' not in n and n.lower().endswith('.xml')];assert len(profiles)==1
    raw=z.read(profiles[0])
  else:raw=p.read_bytes()
  assert b'<!--' not in raw,(str(p),'XML comment remains');count+=1
 counts[dirname]=count
proof={'same33SeedsByteIdenticalTo44':seeds,'commentFreeStoredProfilesByRun':counts,'nativeXmlAndExplicitColorJsonOnly':True}
(out/'integrity.json').write_text(json.dumps(proof,indent=2),encoding='utf-8');print({k:v for k,v in proof.items() if k!='same33SeedsByteIdenticalTo44'})

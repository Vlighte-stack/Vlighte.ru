from pathlib import Path
app=Path('work/app-native39.py').read_text(encoding='utf-8')
app=app.replace(' or hi<=lo','').replace(' or high<low','')
app=app.replace("'ColorEffects1':'COLORMACRO'}", "'ColorEffects1':'COLORMACRO','PanRotate':'PAN2','TiltRotate':'TILT2','Gobo1Pos':'GOBO1_POS','Gobo1PosRotate':'GOBO1_POS','Gobo2Pos':'GOBO2_POS','Gobo2PosRotate':'GOBO2_POS'}")
start="   fs=logical.findall('ChannelFunction')\n   if not fs:raise ValueError('В GDTF отсутствует ChannelFunction.')"
a=app.index(start);b=app.index("    pf,pt=float(fn.get('PhysicalFrom'",a)
app=app[:a]+'''   intervals=gdtf_function_intervals(logical,bits,mode)
   for fi,(fn,lo,hi,condition) in enumerate(intervals):
    if condition[0]:
     master=gdtf_master(mode,condition[0]);c.set('mode',gdtf_native_attribute(master.find('LogicalChannel').get('Attribute')))
'''+app[b:]
needle="    out=E.SubElement(c,mq('ChannelFunction'),attrs);functions+=1"
app=app.replace(needle,"    if condition[0]:attrs.update(mode_dmx_start=str(condition[1]),mode_dmx_end=str(condition[2]))\n"+needle)
# Adapt the native HOG -> MA function, keeping native mode-channel fields.
a=app.rindex('def ma2_from_hog(');b=app.index('\ndef application(',a);body=app[a:b]
body=body.replace("    if any(children(r,'Qualifiers') or children(r,'Escapes') for r in rs):raise ValueError('Квалификаторы HOG требуют отдельного сопоставления MA2.')", "    if any(children(r,'Escapes') for r in rs):raise ValueError('Escapes требуют отдельного сопоставления MA2.')")
body=body.replace('    previous=-1','    previous={}')
body=body.replace("     if not 0<=low<=high<=maximum or low<=previous:raise ValueError('Пересечение или обратный диапазон HOG4 требует сопоставления MA2.')\n     previous=high;", "     condition=native_qualifier_condition(t,r)\n     if not 0<=low<=high<=maximum or low<=previous.get(condition,-1):raise ValueError('Пересечение диапазонов при одинаковом условии HOG4.')\n     previous[condition]=high;")
needle="     E.SubElement(c,mq('ChannelFunction'),index=str(ri),**{"
body=body.replace(needle,"     fn=E.SubElement(c,mq('ChannelFunction'),index=str(ri),**{")
line=next(x for x in body.splitlines() if x.startswith('     fn=E.SubElement'))
body=body.replace(line,line+"\n     if condition:\n      c.set('mode',condition[0]);fn.set('mode_dmx_start',str(condition[1]));fn.set('mode_dmx_end',str(condition[2]))")
app=app[:a]+body+app[b:]
helpers=Path('work/gdtf_breaks40.py').read_text(encoding='utf-8')+'\n'+Path('work/conditional_native40.py').read_text(encoding='utf-8')
app=app.replace('def application(environ,start_response):',helpers+'\n\ndef application(environ,start_response):',1)
Path('work/app-breaks40.py').write_text(app,encoding='utf-8')
for src,dst in [('home-native39.html','home-breaks40.html'),('library-native39.html','library-breaks40.html')]:Path('work',dst).write_text(Path('work',src).read_text(encoding='utf-8').replace('2.00.39','2.00.40').replace('DMX-режим GDTF:','DMX-режим / профиль Break:'),encoding='utf-8')
audit=Path('work/audit_no_recovery39.py').read_text(encoding='utf-8').replace('work/app-native39.py','work/app-breaks40.py').replace('2.00.39','2.00.40').replace('local native39 candidate','local breaks40 candidate')
Path('work/audit_breaks40.py').write_text(audit,encoding='utf-8')

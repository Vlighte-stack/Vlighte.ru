import os,runpy,base64,zipfile,io,tempfile,shutil,json,copy
from pathlib import Path
from lxml import etree
os.environ['VLIGHTE_GEO_BOOTSTRAP']='0';m=runpy.run_path('work/app-breaks40.py');E=m['E'];out=Path('outputs/IP1000_external_no-recovery_2.00.40')
def encoded(root):
 buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:z.writestr('description.xml',m['serialize'](root))
 return base64.b64encode(buf.getvalue()).decode()
def fixture():
 r=E.fromstring('<GDTF DataVersion="1.2"><FixtureType Name="TwoBreaks"><Geometries><Geometry Name="Base"/></Geometries><DMXModes><DMXMode Name="Mode" Geometry="Base"><DMXChannels/></DMXMode></DMXModes></FixtureType></GDTF>');return r,r.find('FixtureType'),r.find('.//DMXMode')
def add(mode,brk,offset,attribute,geometry='Base'):
 c=E.SubElement(mode.find('DMXChannels'),'DMXChannel',DMXBreak=str(brk),Offset=str(offset),Geometry=geometry);lc=E.SubElement(c,'LogicalChannel',Attribute=attribute);E.SubElement(lc,'ChannelFunction',Name=attribute,Attribute=attribute,DMXFrom='0/1',PhysicalFrom='0',PhysicalTo='1',Default='0/1');return c
def semantic_conditions(root):
 mods={x.get('index'):x for x in m['descendants'](root,'Module')};result={}
 for inst in m['descendants'](root,'Instance'):
  module=mods[inst.get('module_index')];attrs={c.get('attribute'):c for c in m['children'](module,'ChannelType')};patch=int(inst.get('patch','1'))
  for c in attrs.values():
   if not c.get('mode'):continue
   master=attrs[c.get('mode')];result[patch+int(c.get('coarse'))-1]=sorted({(patch+int(master.get('coarse'))-1,int(fn.get('mode_dmx_start','0')),int(fn.get('mode_dmx_end','255'))) for fn in m['children'](c,'ChannelFunction')})
 return result
with tempfile.TemporaryDirectory() as tmp:
 rootdir=Path(tmp);(rootdir/'private').mkdir();(rootdir/'private/known.json').write_text('{}');shutil.copyfile('C:/Users/Admin/Documents/HOG4_1000 42.xml',rootdir/'private/strobe.xml');m['import_profile'].__globals__['ROOT']=rootdir
 r,f,mode=fixture();add(mode,1,1,'Dimmer');add(mode,2,1,'ColorAdd_R');add(mode,2,2,'ColorAdd_G');add(mode,2,3,'ColorAdd_B');data=encoded(r);choices=m['import_profile']({'gdtf':data})['modes'];assert [c['name'] for c in choices]==['Mode [DMX Break 1]','Mode [DMX Break 2]']
 footprints=[]
 for choice in choices:
  result=m['import_profile']({'gdtf':data,'mode':choice['name']});ma=m['parse'](result['sourceXml']);footprints.append(m['validate_ma2'](ma));assert '[DMX Break' in m['first'](ma,'FixtureType').get('mode')
 assert footprints==[1,3]
 try:m['import_profile']({'gdtf':data,'mode':'Mode'});raise AssertionError('Implicit break drop')
 except ValueError:pass
 # Overwrite takes the break not assigned to the referenced fixed channels.
 r,f,mode=fixture();geos=f.find('Geometries');E.SubElement(geos,'Geometry',Name='Cell');ref=E.SubElement(geos.find('Geometry'),'GeometryReference',Name='Pixel',Geometry='Cell');E.SubElement(ref,'Break',DMXBreak='1',DMXOffset='11');E.SubElement(ref,'Break',DMXBreak='2',DMXOffset='21');add(mode,1,1,'Dimmer','Cell');add(mode,'Overwrite',1,'ColorAdd_R','Cell');records=m['expanded_gdtf_channels'](f,mode);assert {(b,tuple(v)) for _,_,b,v in records}=={(1,(11,)),(2,(21,))}
 # Sorting is local to a condition; duplicate starts under the same condition
 # remain an error, while mutually exclusive ModeMaster intervals are valid.
 r,f,mode=fixture();c=add(mode,1,1,'Dimmer');lc=c.find('LogicalChannel');fn=lc.find('ChannelFunction');fn.set('DMXFrom','128/1');E.SubElement(lc,'ChannelFunction',Name='Low',DMXFrom='0/1',PhysicalFrom='1',PhysicalTo='0');intervals=m['gdtf_function_intervals'](lc,8,mode);assert [(a,b) for _,a,b,_ in intervals]==[(0,127),(128,255)]
 E.SubElement(lc,'ChannelFunction',Name='Duplicate',DMXFrom='0/1')
 try:m['gdtf_function_intervals'](lc,8,mode);raise AssertionError('Duplicate accepted')
 except ValueError:pass
seed=m['parse']((out/'02_BeskydBeam/seed-MA.xml').read_text(encoding='utf-8'));final=m['parse']((out/'02_BeskydBeam/MA-HOG-GDTF-HOG-MA.xml').read_text(encoding='utf-8'));expected={2:[(6,0,0)],4:[(7,0,0)],14:[(13,0,127),(13,128,255)],16:[(15,0,127),(15,128,255)]};assert semantic_conditions(seed)==semantic_conditions(final)==expected
schema=etree.XMLSchema(etree.parse('work/hog-fixture.xsd'));namespace={'h':m['H']}
for filename in ['seed-HOG.xml','HOG-MA-GDTF-MA-HOG.xml']:
 doc=etree.parse(str(out/'02_BeskydBeam'/filename));lib=doc.find('h:Library',namespace);group=lib.find('h:CompoundTypes',namespace)
 if group is not None:lib.remove(group);doc.find('.//h:Product',namespace).append(group)
 assert schema.validate(doc),str(schema.error_log)
 assert doc.findall('.//h:Qualifier',namespace)
proof={'twoActiveBreaksYieldTwoProfiles':True,'profileFootprints':footprints,'sameAddressAcrossBreaksDoesNotCollide':True,'overwriteOffsets':[[1,11],[2,21]],'implicitDropRejected':True,'unsortedFunctionsCorrectlyPartitioned':True,'duplicateUnconditionalFunctionsRejected':True,'beskydModeMasterConditionsPreserved':expected,'beskydHogQualifierDefinitionsXsdValidWithCompoundLocationAdaptation':True}
(out/'breaks-conditional-verification.json').write_text(json.dumps(proof,indent=2),encoding='utf-8');print(json.dumps(proof))

_ma2_attribute39=ma2_attribute
def ma2_attribute(function,feature):
 match=re.fullmatch(r'(Pan|Tilt) ([1-6])',function)
 if match:return (match[1].upper()+match[2],'POSITION','POSITION',1)
 return _ma2_attribute39(function,feature)

_map_module_channels39=map_module_channels
def map_module_channels(target,source,module):
 prepared=[]
 for c in source:
  clone=copy.deepcopy(c)
  if re.fullmatch(r'(PAN|TILT)[2-6]',c.get('attribute','')):clone.set('attribute',c.get('attribute')[:-1])
  prepared.append(clone)
 _map_module_channels39(target,prepared,module)
 pairs=list(zip(children(target,'Channel'),source));controls={c.get('attribute'):ch for ch,c in pairs};masters={c.get('mode') for _,c in pairs if c.get('mode')}
 # HOG qualifiers address real-world parameter values. A mode controller is
 # exposed as a raw DMX selector so even constant/overlapping physical ranges
 # have an unambiguous native qualifier value. This is surfaced as a warning.
 for attr in masters:
  if attr not in controls:raise ValueError('ModeMaster должен находиться в одном модуле с управляемым каналом.')
  for r in descendants(controls[attr],'Range'):
   r.set('start',r.get('dmxstart'));r.set('end',r.get('dmxend',r.get('dmxstart')))
 for ch,c in pairs:
  master=c.get('mode')
  if not master:continue
  controller=first(controls[master],'Range')
  if controller is None:raise ValueError('ModeMaster не имеет рабочего диапазона.')
  ranges=[r for r in descendants(ch,'Range') if r.get('function') not in ('Cyan','Magenta','Yellow')];cursor=0
  for fn in children(c,'ChannelFunction'):
   maximum=65535 if 'fine' in c.attrib else 255;lo=round(int(fn.get('min_dmx_24','0'))*maximum/16777215);hi=round(int(fn.get('max_dmx_24','16777215'))*maximum/16777215);points={lo,hi+1}
   for s in children(fn,'ChannelSet'):points.update((int(s.get('from_dmx',str(lo))),int(s.get('to_dmx',str(hi)))+1))
   count=len(points)-1
   for r in ranges[cursor:cursor+count]:
    master_source=next(mc for _,mc in pairs if mc.get('attribute')==master);maximum_master='65535' if 'fine' in master_source.attrib else '255';qualifiers=E.SubElement(r,q('Qualifiers'),match='all');E.SubElement(qualifiers,q('Qualifier'),function=controller.get('function'),feature=controller.get('feature'),start=fn.get('mode_dmx_start','0'),end=fn.get('mode_dmx_end',maximum_master))
   cursor+=count
  if cursor!=len(ranges):raise ValueError('Не удалось сопоставить условные диапазоны HOG.')

def native_qualifier_condition(t,r):
 groups=children(r,'Qualifiers')
 if not groups:return None
 qualifiers=children(groups[0],'Qualifier')
 if len(groups)!=1 or groups[0].get('match')!='all' or len(qualifiers)!=1:raise ValueError('Поддерживается одно условие ModeMaster на диапазон.')
 qualifier=qualifiers[0];function=qualifier.get('function');feature=qualifier.get('feature');start=real_number(qualifier.get('start','0'));end=real_number(qualifier.get('end',str(start)))
 if end<start:raise ValueError('Обратный диапазон Qualifier требует сопоставления.')
 spans=[]
 for channel in descendants(t,'Channel'):
  for candidate in descendants(channel,'Range'):
   if candidate.get('function')!=function or candidate.get('feature')!=feature:continue
   a=real_number(candidate.get('start','0'));b=real_number(candidate.get('end',str(a)));low=int(candidate.get('dmxstart'));high=int(candidate.get('dmxend',str(low)))
   if a!=low or b!=high:raise ValueError('ModeMaster с нелинейной шкалой требует отдельного сопоставления.')
   left=max(start,a);right=min(end,b)
   if left<=right:spans.append((round(left),round(right),channel))
 if not spans:raise ValueError('Qualifier ссылается на неизвестный управляющий канал.')
 owners={id(c) for _,_,c in spans}
 if len(owners)!=1:raise ValueError('Qualifier неоднозначен между несколькими каналами.')
 intervals=sorted((a,b) for a,b,_ in spans);cursor=round(start)
 for a,b in intervals:
  if a>cursor:raise ValueError('Разрыв диапазона ModeMaster.')
  cursor=max(cursor,b+1)
 if cursor<=round(end):raise ValueError('Неполный диапазон ModeMaster.')
 return (ma2_attribute(function,feature)[0],round(start),round(end))

_gdtf_from_ma39=gdtf_from_ma
def gdtf_from_ma(ma_xml,name):
 ma=parse(ma_xml)
 if not any(c.get('mode') for c in descendants(ma,'ChannelType')):return _gdtf_from_ma39(ma_xml,name)
 bare=copy.deepcopy(ma)
 for parent in bare.iter():
  for child in list(parent):
   if child.tag is E.Comment:parent.remove(child)
 simplified=copy.deepcopy(bare)
 for c in descendants(simplified,'ChannelType'):
  if not c.get('mode'):continue
  functions=children(c,'ChannelFunction');firstcondition=(functions[0].get('mode_dmx_start','0'),functions[0].get('mode_dmx_end','255'))
  for fn in functions:
   if (fn.get('mode_dmx_start','0'),fn.get('mode_dmx_end','255'))!=firstcondition:c.remove(fn)
  c.attrib.pop('mode',None)
 encoded,warnings=_gdtf_from_ma39(ma2_serialize(simplified),name);root,fixture,modes=read_gdtf(encoded);mode=modes[0];dcs=mode.findall('./DMXChannels/DMXChannel');modules={n.get('index'):n for n in descendants(bare,'Module')};expanded=[(inst,c) for inst in descendants(bare,'Instance') for c in children(modules[inst.get('module_index')],'ChannelType')]
 if len(expanded)!=len(dcs):raise ValueError('Не удалось сопоставить условные каналы GDTF.')
 for index,(inst,c) in enumerate(expanded):
  if not c.get('mode'):continue
  masterindices=[j for j,(other,mc) in enumerate(expanded) if other is inst and mc.get('attribute')==c.get('mode')]
  if len(masterindices)!=1:raise ValueError('Неоднозначный ModeMaster MA2.')
  master=dcs[masterindices[0]];masterid=master.get('Geometry')+'_'+master.find('LogicalChannel').get('Attribute');lc=dcs[index].find('LogicalChannel');prototype=copy.deepcopy(lc.find('ChannelFunction'));lc.clear();lc.set('Attribute',prototype.get('Attribute'));lc.set('Master','None');bits=16 if 'fine' in c.attrib else 8 if 'coarse' in c.attrib else 32;maximum=2**bits-1;resolution=bits//8
  for fi,fn in enumerate(children(c,'ChannelFunction')):
   out=copy.deepcopy(prototype)
   for child in list(out):out.remove(child)
   out.set('Name','Function_'+str(fi));out.set('DMXFrom',str(round(int(fn.get('min_dmx_24','0'))*maximum/16777215))+'/'+str(resolution));out.set('PhysicalFrom',fn.get('physfrom','0'));out.set('PhysicalTo',fn.get('physto','1'));out.set('ModeMaster',masterid)
   mbits=16 if 'fine' in expanded[masterindices[0]][1].attrib else 8;out.set('ModeFrom',fn.get('mode_dmx_start','0')+'/'+str(mbits//8));out.set('ModeTo',fn.get('mode_dmx_end',str(2**mbits-1))+'/'+str(mbits//8))
   for s in children(fn,'ChannelSet'):E.SubElement(out,'ChannelSet',Name=s.get('name',''),DMXFrom=s.get('from_dmx','0')+'/'+str(resolution))
   lc.append(out)
  dcs[index].set('InitialFunction',dcs[index].get('Geometry')+'_'+lc.get('Attribute')+'.'+lc.get('Attribute')+'.Function_0')
 for child in list(root):
  if child.tag is E.Comment:root.remove(child)
 data={'hash':object_fingerprint(serialize(root)),'ma2Xml':ma2_serialize(bare)};root.insert(0,E.Comment(GDTF_EXPORT_MARKER+base64.b64encode(json.dumps(data,separators=(',',':')).encode()).decode()));description=serialize(root).encode()
 if len(description)>2_000_000:raise ValueError('GDTF превышает 2 МБ.')
 buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:z.writestr('description.xml',description)
 return base64.b64encode(buf.getvalue()).decode(),warnings+['Условия ModeMaster сохранены; управляющие параметры HOG используют шкалу DMX.']

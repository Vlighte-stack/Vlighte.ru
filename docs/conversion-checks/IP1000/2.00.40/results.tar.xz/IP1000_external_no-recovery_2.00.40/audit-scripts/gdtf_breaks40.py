def expanded_gdtf_channels(fixture,mode):
 geometries=fixture.find('Geometries')
 if geometries is None:raise ValueError('В GDTF отсутствует геометрия.')
 named={n.get('Name'):n for n in geometries.iter() if n.get('Name')};start=named.get(mode.get('Geometry'));channels=mode.findall('./DMXChannels/DMXChannel');records=[];seen=set();visits=0
 if not channels or len(channels)>1024 or any(len(c.findall('LogicalChannel'))!=1 for c in channels):raise ValueError('Требуется один LogicalChannel на физический канал GDTF.')
 if start is None:raise ValueError('Не найдена геометрия режима GDTF.')
 def walk(node,offsets=None,path=(),stack=()):
  nonlocal visits
  visits+=1
  if visits>2048 or len(stack)>32:raise ValueError('Слишком сложная геометрия GDTF.')
  offsets=offsets or {};key=path+(node.get('Name',''),)
  if node.tag=='GeometryReference':
   target=named.get(node.get('Geometry'))
   if target is None or node.get('Geometry') in stack:raise ValueError('Циклическая или неизвестная геометрия GDTF.')
   local_offsets={}
   for b in node.findall('Break'):
    number=int(b.get('DMXBreak','1'));shift=int(b.get('DMXOffset','1'))-1
    if not 1<=number<=255 or not 0<=shift<=511 or number in local_offsets:raise ValueError('Некорректное определение DMX Break геометрии.')
    local_offsets[number]=shift
   inherited=dict(offsets)
   for number,shift in local_offsets.items():inherited[number]=offsets.get(number,0)+shift
   # Unused entries are valid: the same reference can serve different modes.
   target_names={n.get('Name') for n in target.iter() if n.get('Name')};fixed={int(c.get('DMXBreak','1')) for c in channels if c.get('Geometry') in target_names and c.get('DMXBreak','1')!='Overwrite'};available=set(local_offsets)-fixed
   inherited['overwrite']=next(iter(available)) if len(available)==1 else next(iter(local_offsets)) if len(local_offsets)==1 else offsets.get('overwrite')
   walk(target,inherited,key,stack+(node.get('Geometry'),));return
  for c in channels:
   if c.get('Geometry')!=node.get('Name'):continue
   rawbreak=c.get('DMXBreak','1')
   number=offsets.get('overwrite') if rawbreak=='Overwrite' else int(rawbreak)
   if number is None:raise ValueError('Для Overwrite требуется однозначный DMX Break в GeometryReference.')
   if not 1<=number<=255:raise ValueError('Некорректный номер DMX Break.')
   values=[int(n.strip())+offsets.get(number,0) for n in c.get('Offset','').split(',') if n.strip() and n.strip()!='None']
   if any(not 1<=v<=512 for v in values):raise ValueError('Адрес DMX Break выходит за 512.')
   records.append((key,c,number,values));seen.add(id(c))
   if len(records)>8192:raise ValueError('Слишком много развёрнутых каналов GDTF.')
  for child in node:
   if child.get('Name'):walk(child,offsets,key,stack)
 walk(start)
 if len(seen)!=len(channels):raise ValueError('Не все каналы связаны с геометрией режима GDTF.')
 return records

def gdtf_native_attribute(value):
 return {'PanRotate':'PAN2','TiltRotate':'TILT2','Gobo1Pos':'GOBO1_POS','Gobo1PosRotate':'GOBO1_POS','Gobo2Pos':'GOBO2_POS','Gobo2PosRotate':'GOBO2_POS','Gobo1':'GOBO1','Gobo2':'GOBO2'}.get(value,value[8:] if value.startswith('Vlighte_') else value.upper())

def normalize_gdtf_break(root,fixture,mode,selected=None):
 records=expanded_gdtf_channels(fixture,mode);active=sorted({b for _,_,b,values in records if values})
 if not active:raise ValueError('Нет физических DMX Break.')
 if selected is None and len(active)>1:raise ValueError('Несколько активных DMX Break: выберите отдельный профиль Break.')
 selected=selected or active[0]
 if selected not in active:raise ValueError('Выбранный DMX Break не используется в режиме.')
 needs=selected!=1 or len(active)>1 or any(len(n.findall('Break'))>1 for n in fixture.iter('GeometryReference')) or any(fn.get('ModeMaster') for c in mode.findall('./DMXChannels/DMXChannel') for fn in c.findall('./LogicalChannel/ChannelFunction'))
 if not needs:return root,fixture,mode,[]
 root=copy.deepcopy(root);fixture=root.find('FixtureType');original_name=mode.get('Name');mode=next(n for n in fixture.findall('./DMXModes/DMXMode') if n.get('Name')==original_name)
 geos=fixture.find('Geometries');geos.clear();base=E.SubElement(geos,'Geometry',Name='Break_Profile',Position='{1,0,0,0}{0,1,0,0}{0,0,1,0}{0,0,0,1}');mode.set('Geometry','Break_Profile');target=mode.find('DMXChannels');target.clear();grouped={};aliases={}
 conditional=any(fn.get('ModeMaster') for _,c,b,values in records if b==selected for fn in c.findall('./LogicalChannel/ChannelFunction'))
 # A conditional controller and its follower must live in the same HOG Type.
 for path,c,b,values in records:
  if b!=selected:continue
  key=('Conditional',) if conditional else path
  if key not in grouped:
   name='Group_'+str(len(grouped));grouped[key]=name;E.SubElement(base,'Geometry',Name=name,Position='{1,0,0,0}{0,1,0,0}{0,0,1,0}{0,0,0,1}')
  clone=copy.deepcopy(c);name=grouped[key];oldid=c.get('Geometry')+'_'+c.find('LogicalChannel').get('Attribute');newid=name+'_'+c.find('LogicalChannel').get('Attribute');aliases.setdefault(oldid,[]).append(newid);clone.set('Geometry',name);clone.set('DMXBreak','1');clone.set('Offset',','.join(map(str,values)) if values else 'None')
  initial=clone.get('InitialFunction')
  if initial:clone.set('InitialFunction',newid+'.'+'.'.join(initial.split('.')[1:]))
  target.append(clone)
 for c in target:
  for fn in c.findall('./LogicalChannel/ChannelFunction'):
   master=fn.get('ModeMaster')
   if not master:continue
   head,*tail=master.split('.');matches=aliases.get(head,[])
   if len(set(matches))!=1:raise ValueError('ModeMaster отсутствует в выбранном Break или неоднозначен.')
   fn.set('ModeMaster',matches[0]+('.'+'.'.join(tail) if tail else ''))
 modes=fixture.find('DMXModes')
 for other in list(modes):
  if other is not mode:modes.remove(other)
 warnings=[]
 if len(active)>1 or selected!=1:
  mode.set('Name',original_name+' [DMX Break '+str(selected)+']');warnings.append('Отдельный профиль DMX Break '+str(selected)+': адреса внутри Break сохранены; остальные Break выбираются отдельными профилями.')
 return root,fixture,mode,warnings

def gdtf_master(mode,reference):
 head=reference.split('.')[0]
 matches=[c for c in mode.findall('./DMXChannels/DMXChannel') if c.get('Geometry')+'_'+c.find('LogicalChannel').get('Attribute')==head]
 if len(matches)!=1:raise ValueError('Неоднозначный или неизвестный ModeMaster.')
 return matches[0]

def gdtf_function_intervals(logical,bits,mode):
 fs=logical.findall('ChannelFunction');maximum=2**bits-1;groups={}
 if not fs:raise ValueError('В GDTF отсутствуют функции канала.')
 for fn in fs:
  master=fn.get('ModeMaster','');lowmode=highmode=None
  if master:
   c=gdtf_master(mode,master);offsets=[n for n in c.get('Offset','').split(',') if n and n!='None'];mbits=len(offsets)*8 if offsets else 32;lowmode=gdtf_dmx(fn.get('ModeFrom','0/1'),mbits);highmode=gdtf_dmx(fn.get('ModeTo','0/1'),mbits)
   if not 0<=lowmode<=highmode<=2**mbits-1:raise ValueError('Некорректный диапазон ModeMaster.')
  groups.setdefault((master,lowmode,highmode),[]).append(fn)
 result=[]
 for condition,functions in groups.items():
  functions=sorted(functions,key=lambda fn:gdtf_dmx(fn.get('DMXFrom','0/1'),bits));starts=[gdtf_dmx(fn.get('DMXFrom','0/1'),bits) for fn in functions]
  if len(set(starts))!=len(starts):raise ValueError('Пересечение ChannelFunction при одном и том же условии ModeMaster.')
  if starts[0]!=0:raise ValueError('Начальный незаданный диапазон функции требует явного NoFeature.')
  for index,fn in enumerate(functions):result.append((fn,starts[index],starts[index+1]-1 if index+1<len(starts) else maximum,condition))
 for i,(a,lo,hi,cond) in enumerate(result):
  for b,bl,bh,bc in result[i+1:]:
   if max(lo,bl)>min(hi,bh):continue
   if not cond[0] or cond[0]!=bc[0] or max(cond[1],bc[1])<=min(cond[2],bc[2]):raise ValueError('Неоднозначное пересечение условных диапазонов ChannelFunction.')
 return result

_gdtf_to_ma39=gdtf_to_ma
def gdtf_to_ma(root,fixture,mode,selected_break=None):
 normalized,f,selected,warnings=normalize_gdtf_break(root,fixture,mode,selected_break);ma,summary,notes=_gdtf_to_ma39(normalized,f,selected)
 if any(c.get('mode') for c in descendants(ma,'ChannelType')):warnings.append('ModeMaster сохранён; управляющие параметры HOG используют шкалу DMX вместо исходной физической шкалы селектора.')
 return ma,summary,notes+warnings

_import_profile39=import_profile
def import_profile(payload):
 if 'gdtf' not in payload:return _import_profile39(payload)
 root,fixture,modes=read_gdtf(payload['gdtf']);choices=[];bindings={}
 for mode in modes:
  active=sorted({b for _,_,b,values in expanded_gdtf_channels(fixture,mode) if values})
  for b in active:
   label=mode.get('Name') if len(active)==1 else mode.get('Name')+' [DMX Break '+str(b)+']'
   if label in bindings:raise ValueError('Неоднозначные названия профилей DMX Break.')
   bindings[label]=(mode,b);choices.append({'name':label})
   if len(choices)>512:raise ValueError('Слишком много профилей DMX Break.')
 if payload.get('mode') is None:return {'system':'GDTF','modes':choices,'fixture':fixture.get('Name','GDTF')}
 if payload['mode'] not in bindings:raise ValueError('Выберите отдельный профиль нужного DMX Break.')
 mode,number=bindings[payload['mode']];ma,summary,warnings=gdtf_to_ma(root,fixture,mode,number);recovered=gdtf_ma_recovery(root)
 if recovered is not None and len(choices)==1:ma=recovered;summary['footprint']=validate_ma2(ma)
 source=ma2_serialize(ma);hog,_=convert(ma);hog=attach_ma2_roundtrip(serialize(normalize_compound_location(hog)),source,first(hog,'CompoundType').get('name'))
 if len(source.encode())>2_000_000 or len(hog.encode())>2_000_000:raise ValueError('Профиль превышает лимит XML после преобразования.')
 return {'xml':hog,'sourceXml':source,'system':'GDTF','modes':choices,'summary':summary,'warnings':warnings}
